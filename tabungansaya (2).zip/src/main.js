import welcomeBannerImg from './assets/images/welcome_banner.webp';
import { renderSavingsChart } from './chart.js';
import {
  createId,
  escapeHtml,
  formatAmountInputPreserveCaret,
  formatBackupDate,
  formatDateLabel,
  formatDayDateLabel,
  formatMonthLabel,
  formatRupiah,
  formatShortDate,
  formatThousands,
  getLocalDateString,
  isValidCalendarDate,
  MAX_AMOUNT,
  parseAmountInput,
} from './format.js';
import {
  buildBalanceSeries,
  buildDailyFlowSeries,
  calculateSummary,
  createBackupPayload,
  loadState,
  parseAndValidateBackup,
  saveState,
  sortTransactionsNewest,
} from './storage.js';

const ICONS = {
  home: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"/></svg>`,
  history: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/></svg>`,
  target: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/></svg>`,
  settings: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`,
  plus: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>`,
  minus: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M5 12h14"/></svg>`,
  arrowUp: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></svg>`,
  arrowDown: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14"/><path d="m19 12-7 7-7-7"/></svg>`,
  edit: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>`,
  trash: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/></svg>`,
  sun: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>`,
  moon: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`,
  close: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>`,
  download: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
  upload: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>`,
  search: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>`,
  phone: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>`,
  bell: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>`,
};

const QUICK_AMOUNTS = [5000, 10000, 20000, 50000, 100000];

const appEl = document.getElementById('app');

let persisted = loadState();
let uiState = {
  tab: 'home', // 'home' | 'history' | 'goal' | 'settings'
  historyFilter: 'all', // 'all' | 'deposit' | 'withdraw'
  historyQuery: '',
  historyMonth: 'all', // 'all' | 'YYYY-MM'
  historyLimit: 50,
  chartMode: 'line', // 'line' | 'flow'
  chartRange: 'all', // '7d' | '30d' | 'all'
  chartSelectedIdx: null,
  txSheet: null, // null | { mode, type, editId?, amount, date, note, error }
  confirmSheet: null, // null | { kind, txId?, title, message, confirmLabel }
  iosInstallSheet: false,
  showPasteRestore: false,
  pasteRestoreText: '',
  pendingRestore: null, // null | { transactions, goal, fileName }
  restoreFeedback: null,
  goalFeedback: null,
  goalDraft: null, // null | { name, amount }
  toast: null, // null | { message, undoTx? }
  lastDeletedTx: null,
};

let deferredInstallPrompt = null;
let isStandaloneMode =
  window.matchMedia('(display-mode: standalone)').matches ||
  window.navigator.standalone === true;
const isIOSDevice = /iphone|ipad|ipod/.test(window.navigator.userAgent.toLowerCase());

let toastTimer = null;

const isHttpOrigin =
  window.location.protocol === 'https:' ||
  window.location.hostname === 'localhost' ||
  window.location.hostname === '127.0.0.1';

// Register lightweight offline service worker and warm active asset cache
if ('serviceWorker' in navigator && isHttpOrigin) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then(() => navigator.serviceWorker.ready)
      .then((reg) => {
        const urls = [];
        document.querySelectorAll('script[src], link[rel="stylesheet"], img[src]').forEach((el) => {
          const val = el.getAttribute('src') || el.getAttribute('href');
          if (val) urls.push(val);
        });
        const worker = reg.active || navigator.serviceWorker.controller;
        if (worker && urls.length) {
          worker.postMessage({ type: 'CACHE_URLS', urls });
        }
      })
      .catch(() => {});
  });
}

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  render();
});

window.addEventListener('appinstalled', () => {
  deferredInstallPrompt = null;
  isStandaloneMode = true;
  render();
  showToast('TabunganSaya dipasang di layar utama');
});

window.addEventListener('offline', () => {
  showToast('Mode offline — data tetap tersimpan lokal');
});

window.addEventListener('online', () => {
  showToast('Kembali online');
});

function isDarkActive() {
  return document.documentElement.classList.contains('dark');
}

function applyTheme(theme) {
  const effective =
    theme ||
    (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light');
  const isDark = effective === 'dark';
  document.documentElement.classList.toggle('dark', isDark);

  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) {
    meta.setAttribute('content', isDark ? '#0D1110' : '#F6F7F5');
  }
}

function showToast(message, undoTx = null, actionBtnConfig = null) {
  uiState.toast = { message, undoTx, actionBtnConfig };
  if (toastTimer) clearTimeout(toastTimer);
  renderToast();
  const duration = undoTx || actionBtnConfig ? 6000 : 2400;
  toastTimer = setTimeout(() => {
    uiState.toast = null;
    uiState.lastDeletedTx = null;
    renderToast();
  }, duration);
}

function renderToast() {
  const existing = document.getElementById('ts-toast');
  if (existing) existing.remove();
  if (!uiState.toast) return;

  const hasAction = Boolean(uiState.toast.undoTx || uiState.toast.actionBtnConfig);
  const el = document.createElement('div');
  el.id = 'ts-toast';
  el.className = hasAction ? 'toast toast-with-action' : 'toast';
  el.setAttribute('role', 'status');
  el.setAttribute('aria-live', 'polite');

  const msgSpan = document.createElement('span');
  msgSpan.textContent = uiState.toast.message;
  el.appendChild(msgSpan);

  if (uiState.toast.undoTx) {
    const undoBtn = document.createElement('button');
    undoBtn.type = 'button';
    undoBtn.className = 'toast-undo-btn';
    undoBtn.textContent = 'Urungkan';
    undoBtn.addEventListener('click', () => {
      const txToRestore = uiState.lastDeletedTx;
      if (!txToRestore) return;
      if (!persisted.transactions.some((t) => t.id === txToRestore.id)) {
        persisted.transactions.push(txToRestore);
      }
      uiState.lastDeletedTx = null;
      uiState.toast = null;
      uiState.chartSelectedIdx = null;
      if (toastTimer) clearTimeout(toastTimer);
      renderToast();
      persistAndRender(false);
      showToast('Transaksi dikembalikan');
    });
    el.appendChild(undoBtn);
  } else if (uiState.toast.actionBtnConfig) {
    const cfg = uiState.toast.actionBtnConfig;
    const actBtn = document.createElement('button');
    actBtn.type = 'button';
    actBtn.className = 'toast-undo-btn';
    actBtn.textContent = cfg.label;
    actBtn.addEventListener('click', () => {
      uiState.toast = null;
      if (toastTimer) clearTimeout(toastTimer);
      renderToast();
      cfg.onClick();
    });
    el.appendChild(actBtn);
  }

  document.body.appendChild(el);
}

function persistAndRender(markDataChanged = false) {
  if (markDataChanged) {
    persisted.changesSinceBackup = (persisted.changesSinceBackup || 0) + 1;
  }
  const saved = saveState(persisted);
  render();
  if (!saved) {
    showToast('Penyimpanan perangkat penuh. Unduh backup segera.');
  }
}

function openAddSheet(type = 'deposit') {
  uiState.txSheet = {
    mode: 'add',
    type,
    amount: 0,
    date: getLocalDateString(),
    note: '',
    error: '',
  };
  render();
  focusAmountInput();
}

function openEditSheet(txId) {
  const tx = persisted.transactions.find((t) => t.id === txId);
  if (!tx) return;
  uiState.txSheet = {
    mode: 'edit',
    editId: tx.id,
    type: tx.type,
    amount: tx.amount,
    date: tx.date,
    note: tx.note || '',
    error: '',
  };
  render();
  focusAmountInput();
}

function focusAmountInput() {
  requestAnimationFrame(() => {
    const input = document.getElementById('tx-amount-input');
    if (input) input.focus();
  });
}

function closeTxSheet() {
  uiState.txSheet = null;
  render();
}

function openConfirmDeleteTx(txId) {
  const tx = persisted.transactions.find((t) => t.id === txId);
  if (!tx) return;
  const kindLabel = tx.type === 'deposit' ? 'tabungan masuk' : 'pengambilan uang';
  uiState.confirmSheet = {
    kind: 'deleteTx',
    txId,
    title: 'Hapus Transaksi?',
    message: `Transaksi ${kindLabel} sebesar ${formatRupiah(tx.amount)} (${formatDateLabel(tx.date, true)}) akan dihapus dan saldo dihitung ulang.`,
    confirmLabel: 'Ya, Hapus',
  };
  render();
}

function executeConfirmAction() {
  const sheet = uiState.confirmSheet;
  if (!sheet) return;

  if (sheet.kind === 'deleteTx' && sheet.txId) {
    const removed = persisted.transactions.find((t) => t.id === sheet.txId) || null;
    persisted.transactions = persisted.transactions.filter((t) => t.id !== sheet.txId);
    uiState.chartSelectedIdx = null;
    uiState.confirmSheet = null;
    uiState.lastDeletedTx = removed;
    persistAndRender(true);
    showToast('Transaksi dihapus', removed);
    return;
  }

  if (sheet.kind === 'deleteGoal') {
    persisted.goal = null;
    uiState.confirmSheet = null;
    uiState.goalFeedback = null;
    uiState.goalDraft = null;
    persistAndRender(true);
    showToast('Target tabungan dihapus');
  }
}

function renderTopBar() {
  const dark = isDarkActive();
  const navItems = [
    { id: 'home', label: 'Beranda' },
    { id: 'history', label: 'Riwayat' },
    { id: 'goal', label: 'Target' },
    { id: 'settings', label: 'Pengaturan' },
  ];

  return `
    <header class="top-bar">
      <div class="top-bar-inner">
        <a href="#beranda" class="brand-wordmark" data-nav="home">TabunganSaya</a>
        <nav class="desktop-nav" aria-label="Navigasi utama">
          ${navItems
            .map(
              (item) => `
              <button
                type="button"
                class="desktop-nav-link ${uiState.tab === item.id ? 'is-active' : ''}"
                data-nav="${item.id}"
              >${item.label}</button>
            `
            )
            .join('')}
        </nav>
        <div class="top-bar-actions">
          ${
            !isStandaloneMode && deferredInstallPrompt
              ? `<button
                  type="button"
                  class="btn btn-secondary top-install-btn"
                  data-action="install-app"
                  aria-label="Pasang Aplikasi TabunganSaya"
                >
                  ${ICONS.download}
                  <span>Pasang</span>
                </button>`
              : ''
          }
          <button
            type="button"
            class="icon-btn"
            data-action="toggle-theme"
            aria-label="${dark ? 'Ganti ke Mode Terang' : 'Ganti ke Mode Gelap'}"
            title="${dark ? 'Mode Terang' : 'Mode Gelap'}"
          >
            ${dark ? ICONS.sun : ICONS.moon}
          </button>
          <button
            type="button"
            class="btn btn-primary desktop-cta-btn"
            data-action="open-add-deposit"
          >
            ${ICONS.plus}
            <span>Catat Tabungan</span>
          </button>
        </div>
      </div>
    </header>
  `;
}

function renderBottomNav() {
  const items = [
    { id: 'home', label: 'Beranda', icon: ICONS.home },
    { id: 'history', label: 'Riwayat', icon: ICONS.history },
    { id: 'goal', label: 'Target', icon: ICONS.target },
    { id: 'settings', label: 'Pengaturan', icon: ICONS.settings },
  ];

  return `
    <nav class="bottom-nav" aria-label="Menu bawah">
      <div class="bottom-nav-grid">
        ${items
          .map(
            (item) => `
            <button
              type="button"
              class="nav-item ${uiState.tab === item.id ? 'is-active' : ''}"
              data-nav="${item.id}"
              aria-current="${uiState.tab === item.id ? 'page' : 'false'}"
            >
              ${item.icon}
              <span>${item.label}</span>
            </button>
          `
          )
          .join('')}
      </div>
    </nav>
  `;
}

function renderTransactionListHtml(transactions, allowActions = true, emptyCustom = null) {
  if (!transactions.length) {
    if (emptyCustom) {
      return `
        <div class="empty-state">
          <p class="empty-state-title">${escapeHtml(emptyCustom.title)}</p>
          <p class="empty-state-desc">${escapeHtml(emptyCustom.desc)}</p>
        </div>
      `;
    }
    return `
      <div class="empty-state">
        <p class="empty-state-title">Belum ada catatan transaksi</p>
        <p class="empty-state-desc">Mulai catat uang tabungan harian atau cash di celengan Anda.</p>
        <button type="button" class="btn btn-primary" data-action="open-add-deposit">
          ${ICONS.plus}
          <span>Tambah Tabungan</span>
        </button>
      </div>
    `;
  }

  return `
    <ul class="tx-list">
      ${transactions
        .map((tx) => {
          const isDeposit = tx.type === 'deposit';
          const defaultTitle = isDeposit ? 'Tabungan Masuk' : 'Ambil Uang';
          const titleText = tx.note ? tx.note : defaultTitle;
          const typeLabel = isDeposit ? 'Masuk' : 'Pengambilan';
          const amountPrefix = isDeposit ? '+' : '-';

          return `
            <li class="tx-item">
              <div class="tx-icon ${isDeposit ? 'is-deposit' : 'is-withdraw'}" aria-hidden="true">
                ${isDeposit ? ICONS.arrowUp : ICONS.arrowDown}
              </div>
              <div class="tx-body">
                <p class="tx-note">${escapeHtml(titleText)}</p>
                <p class="tx-meta">
                  <span>${escapeHtml(formatDateLabel(tx.date, true))}</span>
                  <span aria-hidden="true">·</span>
                  <span>${typeLabel}</span>
                </p>
              </div>
              <div class="tx-right">
                <span class="tx-amount tabular-nums ${isDeposit ? 'text-positive' : 'text-negative'}">
                  ${amountPrefix}${escapeHtml(formatRupiah(tx.amount))}
                </span>
                ${
                  allowActions
                    ? `
                  <div class="tx-actions">
                    <button
                      type="button"
                      class="tx-action-btn"
                      data-edit-tx="${escapeHtml(tx.id)}"
                      aria-label="Edit transaksi ${escapeHtml(titleText)}"
                      title="Edit"
                    >
                      ${ICONS.edit}
                    </button>
                    <button
                      type="button"
                      class="tx-action-btn is-delete"
                      data-delete-tx="${escapeHtml(tx.id)}"
                      aria-label="Hapus transaksi ${escapeHtml(titleText)}"
                      title="Hapus"
                    >
                      ${ICONS.trash}
                    </button>
                  </div>
                `
                    : ''
                }
              </div>
            </li>
          `;
        })
        .join('')}
    </ul>
  `;
}

function renderGoalSummaryCard(summary, compact = false) {
  const gs = summary.goalStats;
  if (!gs) {
    return `
      <section class="card" aria-labelledby="goal-card-heading">
        <div class="card-header">
          <h2 id="goal-card-heading" class="card-title">Target Tabungan</h2>
          <button type="button" class="text-link-btn" data-nav="goal">Atur Target</button>
        </div>
        <p class="field-hint" style="margin:0;">
          Belum ada target tabungan. Tetapkan nominal tujuan agar progres menabung lebih terarah.
        </p>
      </section>
    `;
  }

  const daily30 = !gs.isAchieved && gs.remaining > 0 ? Math.ceil(gs.remaining / 30) : 0;

  return `
    <section class="card" aria-labelledby="goal-card-heading">
      <div class="card-header">
        <h2 id="goal-card-heading" class="card-title">Target Tabungan</h2>
        ${
          compact
            ? `<button type="button" class="text-link-btn" data-nav="goal">Ubah</button>`
            : ''
        }
      </div>
      <div class="goal-header-row">
        <span class="goal-name">${escapeHtml(gs.name)}</span>
        <span class="goal-percent tabular-nums">${gs.percent}%</span>
      </div>
      <div class="progress-track" role="progressbar" aria-valuenow="${gs.percent}" aria-valuemin="0" aria-valuemax="100" aria-label="Progres target tabungan">
        <div class="progress-fill ${gs.isAchieved ? 'is-complete' : ''}" style="width: ${gs.percent}%"></div>
      </div>
      <div class="goal-meta-row tabular-nums">
        <span>Terkumpul ${escapeHtml(formatRupiah(gs.currentAmount))} dari ${escapeHtml(formatRupiah(gs.targetAmount))}</span>
        <span>${gs.isAchieved ? 'Target tercapai' : `Kurang ${escapeHtml(formatRupiah(gs.remaining))}`}</span>
      </div>
      ${
        !compact && daily30 > 0
          ? `<p class="goal-note tabular-nums">Gambaran: menabung sekitar ${escapeHtml(formatRupiah(daily30))}/hari untuk mencapai sisa target dalam 30 hari.</p>`
          : ''
      }
      <p class="goal-note">Target hanya sebagai penanda progres dan tidak menambah total saldo.</p>
    </section>
  `;
}

function renderChartCard(chartPoints) {
  const modes = [
    { id: 'line', label: 'Garis Saldo' },
    { id: 'flow', label: 'Masuk / Keluar' },
  ];
  const ranges = [
    { id: '7d', label: '7H' },
    { id: '30d', label: '30H' },
    { id: 'all', label: 'Semua' },
  ];

  const chartDateLabel = (() => {
    if (!chartPoints || chartPoints.length === 0) {
      return formatDayDateLabel(getLocalDateString(), false);
    }
    const firstDate = chartPoints[0].date;
    const lastDate = chartPoints[chartPoints.length - 1].date;
    if (!firstDate || firstDate === lastDate) {
      return formatDayDateLabel(lastDate || getLocalDateString(), false);
    }
    const sameYear = firstDate.slice(0, 4) === lastDate.slice(0, 4);
    const startPart = sameYear ? formatShortDate(firstDate) : formatDateLabel(firstDate, false);
    return `${startPart} – ${formatDateLabel(lastDate, false)}`;
  })();

  return `
    <section class="card" aria-labelledby="chart-heading">
      <div class="card-header">
        <h2 id="chart-heading" class="card-title">Grafik Naik Turun</h2>
        <span class="chart-date-range tabular-nums">${escapeHtml(chartDateLabel)}</span>
      </div>
      <div class="chart-controls-row">
        <div class="segmented segmented-compact" role="group" aria-label="Jenis grafik">
          ${modes
            .map(
              (m) => `
              <button
                type="button"
                class="segmented-btn ${uiState.chartMode === m.id ? 'is-active' : ''}"
                data-chart-mode="${m.id}"
              >${m.label}</button>
            `
            )
            .join('')}
        </div>
        <div class="segmented segmented-compact" role="group" aria-label="Rentang grafik">
          ${ranges
            .map(
              (r) => `
              <button
                type="button"
                class="segmented-btn ${uiState.chartRange === r.id ? 'is-active' : ''}"
                data-chart-range="${r.id}"
              >${r.label}</button>
            `
            )
            .join('')}
        </div>
      </div>
      <div id="chart-container" data-points-count="${chartPoints.length}"></div>
    </section>
  `;
}

function getGreetingText() {
  const hour = new Date().getHours();
  if (hour >= 4 && hour < 11) return 'Selamat pagi';
  if (hour >= 11 && hour < 15) return 'Selamat siang';
  if (hour >= 15 && hour < 18) return 'Selamat sore';
  return 'Selamat malam';
}

function renderWelcomeHero(summary) {
  const greeting = getGreetingText();

  if (persisted.welcomeCollapsed) {
    return `
      <div class="welcome-collapsed-bar">
        <p class="welcome-collapsed-text">${escapeHtml(greeting)}, selamat datang di TabunganSaya</p>
        <button type="button" class="welcome-toggle-btn" data-action="toggle-welcome">
          Tampilkan sapaan
        </button>
      </div>
    `;
  }

  const hasTx = summary.totalCount > 0;
  const headline = hasTx
    ? 'Selamat datang kembali di TabunganSaya'
    : 'Selamat datang di TabunganSaya';
  const subcopy = hasTx
    ? 'Langkah kecil yang rutin hari ini membuat celengan Anda terus bertumbuh tanpa terasa.'
    : 'Catat uang tabungan harian atau cash di celengan dengan cepat, simpel, dan langsung tersimpan di perangkat Anda.';

  return `
    <section class="welcome-card" aria-labelledby="welcome-heading">
      <div class="welcome-grid">
        <div class="welcome-body">
          <div class="welcome-top-row">
            <p class="welcome-kicker">${escapeHtml(greeting)}</p>
            <button type="button" class="welcome-toggle-btn" data-action="toggle-welcome" aria-label="Sembunyikan pembuka">
              Sembunyikan
            </button>
          </div>
          <h1 id="welcome-heading" class="welcome-title">${headline}</h1>
          <p class="welcome-desc">${subcopy}</p>
        </div>
        <div class="welcome-media">
          <img
            src="${welcomeBannerImg}"
            alt="Celengan keramik hijau dan dompet koin di meja berlimpah cahaya pagi"
            width="840"
            height="468"
            decoding="async"
            class="welcome-img"
            referrerpolicy="no-referrer"
            onerror="this.style.display='none'"
          />
          <div class="welcome-scrim" aria-hidden="true"></div>
        </div>
      </div>
    </section>
  `;
}

function renderHomeView(summary, newestTx, chartPoints) {
  const recentTx = newestTx.slice(0, 4);
  const balanceClass = summary.totalBalance < 0 ? 'is-negative' : '';
  const monthDaysLabel =
    summary.monthSavingDays > 0
      ? `${summary.monthSavingDays} hari menabung`
      : 'Belum menabung bulan ini';

  return `
    ${renderWelcomeHero(summary)}
    <div class="dashboard-grid">
      <div class="dashboard-col">
        <section class="card balance-card" aria-labelledby="saldo-heading">
          <p id="saldo-heading" class="balance-label">Total Saldo Tabungan</p>
          <p class="balance-amount tabular-nums ${balanceClass}">${escapeHtml(formatRupiah(summary.totalBalance))}</p>

          <div class="quick-actions">
            <button type="button" class="btn btn-primary" data-action="open-add-deposit">
              ${ICONS.plus}
              <span>Tabung</span>
            </button>
            <button type="button" class="btn btn-secondary" data-action="open-add-withdraw">
              ${ICONS.minus}
              <span>Ambil</span>
            </button>
          </div>

          <div class="balance-stats">
            <div class="stat-item">
              <span class="stat-label">Total Masuk (${summary.depositCount})</span>
              <span class="stat-value tabular-nums text-positive">+${escapeHtml(formatRupiah(summary.totalDeposit))}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">Total Diambil (${summary.withdrawCount})</span>
              <span class="stat-value tabular-nums text-negative">-${escapeHtml(formatRupiah(summary.totalWithdraw))}</span>
            </div>
          </div>

          <p class="balance-month-note tabular-nums">
            <span>Bulan ini: <strong class="text-positive">+${escapeHtml(formatRupiah(summary.monthDeposit))}</strong></span>
            <span aria-hidden="true">·</span>
            <span>${escapeHtml(monthDaysLabel)}</span>
          </p>
        </section>

        ${renderGoalSummaryCard(summary, true)}
      </div>

      <div class="dashboard-col">
        ${renderChartCard(chartPoints)}

        <section class="card" aria-labelledby="recent-heading">
          <div class="card-header">
            <h2 id="recent-heading" class="card-title">Transaksi Terbaru</h2>
            ${
              newestTx.length > 0
                ? `<button type="button" class="text-link-btn" data-nav="history">Lihat Semua (${newestTx.length})</button>`
                : ''
            }
          </div>
          ${renderTransactionListHtml(recentTx, true)}
        </section>
      </div>
    </div>
  `;
}

function getFilteredHistory(newestTx) {
  const query = uiState.historyQuery.trim().toLowerCase();
  return newestTx.filter((t) => {
    if (uiState.historyFilter !== 'all' && t.type !== uiState.historyFilter) return false;
    if (uiState.historyMonth !== 'all' && !t.date.startsWith(uiState.historyMonth)) return false;
    if (query) {
      const fallbackLabel = t.type === 'deposit' ? 'tabungan masuk' : 'ambil uang';
      const hay = `${t.note || ''} ${fallbackLabel} ${t.date}`.toLowerCase();
      if (!hay.includes(query)) return false;
    }
    return true;
  });
}

function renderHistoryListOnly(newestTx) {
  const filtered = getFilteredHistory(newestTx);
  const hasFilter =
    uiState.historyFilter !== 'all' ||
    uiState.historyMonth !== 'all' ||
    uiState.historyQuery.trim() !== '';

  const visible = filtered.slice(0, uiState.historyLimit);
  const remainingCount = filtered.length - visible.length;

  const listHtml = renderTransactionListHtml(
    visible,
    true,
    hasFilter
      ? {
          title: 'Tidak ada transaksi yang cocok',
          desc: 'Coba ubah kata kunci pencarian, bulan, atau kategori transaksi.',
        }
      : null
  );

  if (remainingCount <= 0) return listHtml;

  return `
    ${listHtml}
    <div style="margin-top: 14px;">
      <button type="button" class="btn btn-secondary btn-full" data-action="load-more-history">
        Tampilkan lebih banyak (${remainingCount} lagi)
      </button>
    </div>
  `;
}

function renderHistoryView(summary, newestTx) {
  const filters = [
    { id: 'all', label: `Semua (${newestTx.length})` },
    { id: 'deposit', label: 'Masuk' },
    { id: 'withdraw', label: 'Ambil' },
  ];

  return `
    <div class="view-stack">
      <section class="card" aria-labelledby="history-heading">
        <div class="card-header">
          <h1 id="history-heading" class="card-title">Riwayat Transaksi</h1>
          <button type="button" class="text-link-btn" data-action="open-add-deposit">+ Catat Baru</button>
        </div>

        <div class="segmented segmented-full" style="margin-bottom: 12px;" role="group" aria-label="Filter jenis transaksi">
          ${filters
            .map(
              (f) => `
              <button
                type="button"
                class="segmented-btn ${uiState.historyFilter === f.id ? 'is-active' : ''}"
                data-history-filter="${f.id}"
              >${f.label}</button>
            `
            )
            .join('')}
        </div>

        <div class="history-toolbar">
          <label class="search-wrap" aria-label="Cari catatan transaksi">
            ${ICONS.search}
            <input
              id="history-search-input"
              type="search"
              class="search-input"
              placeholder="Cari catatan (mis. celengan)..."
              value="${escapeHtml(uiState.historyQuery)}"
            />
          </label>
          <select id="history-month-select" class="select-control" aria-label="Filter bulan">
            <option value="all" ${uiState.historyMonth === 'all' ? 'selected' : ''}>Semua Bulan</option>
            ${summary.availableMonths
              .map(
                (ym) => `
                <option value="${escapeHtml(ym)}" ${uiState.historyMonth === ym ? 'selected' : ''}>
                  ${escapeHtml(formatMonthLabel(ym))}
                </option>
              `
              )
              .join('')}
          </select>
        </div>

        <div id="history-list-container">
          ${renderHistoryListOnly(newestTx)}
        </div>
      </section>
    </div>
  `;
}

function renderGoalView(summary, chartPoints) {
  const existingGoal = persisted.goal;
  const feedback = uiState.goalFeedback;
  const draftName = uiState.goalDraft ? uiState.goalDraft.name : existingGoal ? existingGoal.name : '';
  const draftAmountText = uiState.goalDraft
    ? formatThousands(uiState.goalDraft.amount)
    : existingGoal
      ? formatThousands(existingGoal.targetAmount)
      : '';

  return `
    <div class="dashboard-grid">
      <div class="dashboard-col">
        ${renderGoalSummaryCard(summary, false)}

        <section class="card" aria-labelledby="goal-form-heading">
          <div class="card-header">
            <h2 id="goal-form-heading" class="card-title">${existingGoal ? 'Ubah Target Tabungan' : 'Buat Target Tabungan'}</h2>
          </div>

          <form id="goal-form" class="form-stack" novalidate>
            <div class="field">
              <label for="goal-name-input" class="field-label">Nama Target</label>
              <input
                id="goal-name-input"
                type="text"
                maxlength="60"
                class="input-standalone"
                placeholder="Contoh: Dana Darurat, Beli HP, Liburan"
                value="${escapeHtml(draftName)}"
              />
            </div>

            <div class="field">
              <label for="goal-amount-input" class="field-label">Nominal Target</label>
              <div class="input-wrap">
                <span class="input-prefix">Rp</span>
                <input
                  id="goal-amount-input"
                  type="text"
                  inputmode="numeric"
                  autocomplete="off"
                  class="input-control is-amount tabular-nums"
                  placeholder="0"
                  value="${escapeHtml(draftAmountText)}"
                />
              </div>
            </div>

            ${
              feedback
                ? `<div class="inline-alert ${feedback.type === 'error' ? 'is-error' : 'is-success'}">${escapeHtml(feedback.message)}</div>`
                : ''
            }

            <button type="submit" class="btn btn-primary btn-full">Simpan Target</button>
            ${
              existingGoal
                ? `<button type="button" class="btn btn-danger-outline btn-full" data-action="delete-goal">Hapus Target</button>`
                : ''
            }
          </form>
        </section>
      </div>

      <div class="dashboard-col">
        ${renderChartCard(chartPoints)}
      </div>
    </div>
  `;
}

function renderSettingsView(summary) {
  const dark = isDarkActive();
  const pending = uiState.pendingRestore;
  const rFeedback = uiState.restoreFeedback;
  const lastBackupLabel = persisted.lastBackupAt
    ? `Backup terakhir: ${formatBackupDate(persisted.lastBackupAt)}`
    : 'Belum pernah membuat backup.';
  const pendingChanges = persisted.changesSinceBackup || 0;

  const showInstallCard = !isStandaloneMode && isHttpOrigin;

  return `
    <div class="dashboard-grid">
      <div class="dashboard-col">
        <section class="card" aria-labelledby="theme-heading">
          <h2 id="theme-heading" class="card-title" style="margin-bottom: 14px;">Tampilan</h2>
          <div class="setting-row">
            <div class="setting-info">
              <p class="setting-title">Mode Tampilan</p>
              <p class="setting-desc">Saat ini menggunakan ${dark ? 'Dark Mode' : 'Light Mode'}</p>
            </div>
            <button type="button" class="btn btn-secondary" data-action="toggle-theme">
              ${dark ? ICONS.sun : ICONS.moon}
              <span>${dark ? 'Light Mode' : 'Dark Mode'}</span>
            </button>
          </div>
        </section>

        ${
          showInstallCard
            ? `
          <section class="card" aria-labelledby="install-heading">
            <h2 id="install-heading" class="card-title" style="margin-bottom: 6px;">Pasang / Unduh Aplikasi</h2>
            <p class="field-hint" style="margin:0 0 14px;">
              Pasang ke layar utama HP atau unduh satu file HTML mandiri yang bisa langsung dibuka offline di browser tanpa internet.
            </p>
            <div class="form-stack" style="gap: 10px;">
              <button type="button" class="btn btn-primary btn-full" data-action="download-offline-app">
                ${ICONS.download}
                <span>Unduh Aplikasi Offline (.html)</span>
              </button>
              <button type="button" class="btn btn-secondary btn-full" data-action="${deferredInstallPrompt ? 'install-app' : 'open-ios-install'}">
                ${ICONS.phone}
                <span>${deferredInstallPrompt ? 'Pasang ke Layar Utama' : 'Cara Pasang di Layar Utama'}</span>
              </button>
            </div>
          </section>
        `
            : ''
        }

        <section class="card" aria-labelledby="reminder-heading">
          <div class="setting-row">
            <div class="setting-info">
              <h2 id="reminder-heading" class="card-title" style="margin-bottom: 2px;">Pengingat Harian</h2>
              <p class="setting-desc">
                ${persisted.reminder.enabled ? `Aktif setiap jam ${escapeHtml(persisted.reminder.time)}` : 'Nonaktif'}
              </p>
            </div>
            <button
              type="button"
              class="switch-btn"
              role="switch"
              aria-checked="${persisted.reminder.enabled ? 'true' : 'false'}"
              aria-label="Aktifkan pengingat harian"
              data-action="toggle-reminder"
            >
              <span class="switch-track" aria-hidden="true">
                <span class="switch-thumb"></span>
              </span>
            </button>
          </div>

          <div class="reminder-panel">
            <div class="reminder-time-row">
              <label for="reminder-time-input" class="field-label">Jam Pengingat</label>
              <input
                id="reminder-time-input"
                type="time"
                class="time-input tabular-nums"
                value="${escapeHtml(persisted.reminder.time)}"
              />
            </div>

            ${(() => {
              const notifSupported = typeof window !== 'undefined' && 'Notification' in window;
              if (!notifSupported) {
                return `<p class="field-hint" style="margin:0;">Pengingat akan muncul sebagai toast di dalam aplikasi saat dibuka pada jam tersebut.</p>`;
              }
              const perm = Notification.permission;
              if (perm === 'granted') {
                return `<p class="field-hint" style="margin:0;">Notifikasi browser dan toast dalam aplikasi sudah siap digunakan.</p>`;
              }
              if (perm === 'denied') {
                return `<p class="field-hint" style="margin:0;">Notifikasi browser diblokir. Pengingat tetap tampil sebagai toast di dalam aplikasi.</p>`;
              }
              return `
                <button type="button" class="btn btn-secondary btn-full" data-action="request-notification">
                  ${ICONS.bell}
                  <span>Izinkan Notifikasi Browser</span>
                </button>
              `;
            })()}

            <button type="button" class="text-link-btn" style="justify-content:center;" data-action="test-reminder">
              Uji Pengingat Sekarang
            </button>
          </div>
        </section>

        <section class="card" aria-labelledby="storage-info-heading">
          <h2 id="storage-info-heading" class="card-title" style="margin-bottom: 10px;">Penyimpanan Lokal</h2>
          <p class="field-hint" style="margin:0;">
            Semua data (${summary.totalCount} transaksi) disimpan langsung di memori browser perangkat ini tanpa akun dan tanpa koneksi bank.
          </p>
        </section>
      </div>

      <div class="dashboard-col">
        <section class="card" aria-labelledby="backup-heading">
          <h2 id="backup-heading" class="card-title" style="margin-bottom: 6px;">Backup & Restore Data</h2>
          <p class="field-hint" style="margin:0;">
            Simpan salinan data ke file JSON agar aman saat ganti HP atau membersihkan data browser.
          </p>
          <p class="backup-status-text">
            ${escapeHtml(lastBackupLabel)}
            ${
              pendingChanges > 0 && summary.totalCount > 0
                ? `<span class="backup-status-warn"> · ${pendingChanges} perubahan belum di-backup</span>`
                : ''
            }
          </p>

          <div class="backup-actions">
            <button type="button" class="btn btn-primary btn-full" data-action="download-backup">
              ${ICONS.download}
              <span>Unduh Backup (.json)</span>
            </button>

            <button type="button" class="btn btn-secondary btn-full" data-action="copy-backup">
              <span>Salin Teks Backup</span>
            </button>

            <label class="btn btn-secondary btn-full" for="restore-file-input" style="cursor: pointer;">
              ${ICONS.upload}
              <span>Pilih File Restore (.json)</span>
            </label>
            <input
              id="restore-file-input"
              type="file"
              accept=".json,application/json"
              class="file-input-hidden"
            />

            <button type="button" class="text-link-btn" style="justify-content:center;" data-action="toggle-paste-restore">
              ${uiState.showPasteRestore ? 'Tutup kolom tempel teks' : 'Atau tempel teks JSON backup'}
            </button>
          </div>

          ${
            uiState.showPasteRestore
              ? `
            <div class="paste-restore-box">
              <label for="paste-restore-input" class="field-label">Tempel Teks JSON Backup</label>
              <textarea
                id="paste-restore-input"
                class="textarea-control"
                placeholder='{"app":"TabunganSaya", ...}'
              >${escapeHtml(uiState.pasteRestoreText)}</textarea>
              <button type="button" class="btn btn-secondary btn-full" data-action="check-paste-restore">
                Periksa Teks Backup
              </button>
            </div>
          `
              : ''
          }

          ${
            rFeedback
              ? `<div class="inline-alert ${rFeedback.type === 'error' ? 'is-error' : 'is-success'}" style="margin-top: 12px;">${escapeHtml(rFeedback.message)}</div>`
              : ''
          }

          ${
            pending
              ? `
                <div class="restore-preview">
                  <p class="restore-preview-title">Pratinjau: ${escapeHtml(pending.fileName)}</p>
                  <p class="restore-preview-meta">
                    ${pending.transactions.length} transaksi${pending.goal ? ` · Target: ${escapeHtml(pending.goal.name)}` : ' · Tanpa target'}
                  </p>
                  <div class="row-btns">
                    <button type="button" class="btn btn-secondary" data-action="cancel-restore">Batal</button>
                    <button type="button" class="btn btn-primary" data-action="confirm-restore">Pulihkan</button>
                  </div>
                </div>
              `
              : ''
          }
        </section>
      </div>
    </div>
  `;
}

function renderTxSheet(summary) {
  const sheet = uiState.txSheet;
  if (!sheet) return '';

  const isDeposit = sheet.type === 'deposit';
  const isEdit = sheet.mode === 'edit';
  const title = isEdit
    ? 'Edit Transaksi'
    : isDeposit
      ? 'Catat Tabungan'
      : 'Catat Pengambilan Uang';

  const notePlaceholder = isDeposit
    ? 'Contoh: Menabung cash di celengan Rp10.000'
    : 'Contoh: Ambil uang untuk keperluan mendadak';

  const currentEditableBalance = isEdit
    ? (() => {
        const orig = persisted.transactions.find((t) => t.id === sheet.editId);
        if (!orig) return summary.totalBalance;
        return orig.type === 'deposit'
          ? summary.totalBalance - orig.amount
          : summary.totalBalance + orig.amount;
      })()
    : summary.totalBalance;

  const exceedsBalance = !isDeposit && sheet.amount > 0 && sheet.amount > currentEditableBalance;

  return `
    <div class="modal-backdrop" id="tx-sheet-backdrop" role="dialog" aria-modal="true" aria-labelledby="tx-sheet-title">
      <div class="modal-sheet">
        <div class="sheet-handle" aria-hidden="true"></div>
        <div class="sheet-header">
          <h2 id="tx-sheet-title" class="sheet-title">${title}</h2>
          <button type="button" class="icon-btn" data-action="close-tx-sheet" aria-label="Tutup form">
            ${ICONS.close}
          </button>
        </div>

        <form id="tx-form" class="form-stack" novalidate>
          <div class="segmented segmented-two" role="group" aria-label="Jenis transaksi">
            <button
              type="button"
              class="segmented-btn ${isDeposit ? 'is-active' : ''}"
              data-sheet-type="deposit"
            >Tabung (+)</button>
            <button
              type="button"
              class="segmented-btn ${!isDeposit ? 'is-active' : ''}"
              data-sheet-type="withdraw"
            >Ambil (-)</button>
          </div>

          <div class="field">
            <label for="tx-amount-input" class="field-label">Nominal Uang</label>
            <div class="input-wrap">
              <span class="input-prefix">Rp</span>
              <input
                id="tx-amount-input"
                type="text"
                inputmode="numeric"
                autocomplete="off"
                class="input-control is-amount tabular-nums"
                placeholder="0"
                value="${escapeHtml(formatThousands(sheet.amount))}"
              />
            </div>
            <div class="quick-chips" aria-label="Pilihan nominal cepat">
              ${QUICK_AMOUNTS.map(
                (val) => `
                <button type="button" class="quick-chip-btn tabular-nums" data-quick-amount="${val}">
                  +${escapeHtml(formatThousands(val))}
                </button>
              `
              ).join('')}
              <button type="button" class="quick-chip-btn is-reset" data-action="reset-tx-amount">
                Reset
              </button>
            </div>
          </div>

          <div class="field">
            <label for="tx-date-input" class="field-label">${isDeposit ? 'Tanggal Menabung' : 'Tanggal Pengambilan'}</label>
            <input
              id="tx-date-input"
              type="date"
              class="input-standalone"
              value="${escapeHtml(sheet.date)}"
            />
          </div>

          <div class="field">
            <label for="tx-note-input" class="field-label">Catatan (opsional)</label>
            <input
              id="tx-note-input"
              type="text"
              maxlength="120"
              class="input-standalone"
              placeholder="${notePlaceholder}"
              value="${escapeHtml(sheet.note)}"
            />
          </div>

          <div id="tx-warning-slot">
            ${
              exceedsBalance
                ? `<div class="inline-alert is-warning">Nominal melebihi saldo saat ini (${escapeHtml(formatRupiah(currentEditableBalance))}).</div>`
                : ''
            }
          </div>

          ${
            sheet.error
              ? `<div class="inline-alert is-error">${escapeHtml(sheet.error)}</div>`
              : ''
          }

          <button type="submit" class="btn btn-primary btn-full">
            ${isEdit ? 'Simpan Perubahan' : isDeposit ? 'Simpan Tabungan' : 'Catat Pengambilan'}
          </button>
        </form>
      </div>
    </div>
  `;
}

function renderConfirmSheet() {
  const sheet = uiState.confirmSheet;
  if (!sheet) return '';

  return `
    <div class="modal-backdrop" id="confirm-sheet-backdrop" role="alertdialog" aria-modal="true" aria-labelledby="confirm-sheet-title">
      <div class="modal-sheet">
        <div class="sheet-handle" aria-hidden="true"></div>
        <div class="sheet-header">
          <h2 id="confirm-sheet-title" class="sheet-title">${escapeHtml(sheet.title)}</h2>
          <button type="button" class="icon-btn" data-action="close-confirm-sheet" aria-label="Batal">
            ${ICONS.close}
          </button>
        </div>
        <p class="field-hint" style="margin: 0 0 18px; font-size: 0.9375rem;">${escapeHtml(sheet.message)}</p>
        <div class="row-btns">
          <button type="button" class="btn btn-secondary" data-action="close-confirm-sheet">Batal</button>
          <button type="button" class="btn btn-danger" data-action="confirm-action">${escapeHtml(sheet.confirmLabel)}</button>
        </div>
      </div>
    </div>
  `;
}

function renderIOSInstallSheet() {
  if (!uiState.iosInstallSheet) return '';

  return `
    <div class="modal-backdrop" id="ios-sheet-backdrop" role="dialog" aria-modal="true" aria-labelledby="ios-sheet-title">
      <div class="modal-sheet">
        <div class="sheet-handle" aria-hidden="true"></div>
        <div class="sheet-header">
          <h2 id="ios-sheet-title" class="sheet-title">${isIOSDevice ? 'Pasang di Layar Utama iPhone' : 'Cara Pasang di HP'}</h2>
          <button type="button" class="icon-btn" data-action="close-ios-install" aria-label="Tutup">
            ${ICONS.close}
          </button>
        </div>
        ${
          isIOSDevice
            ? `
          <p class="field-hint" style="margin: 0 0 10px; font-size: 0.9375rem;">
            1. Buka link aplikasi di Safari, lalu ketuk tombol <strong>Bagikan (Share)</strong> di bagian bawah.
          </p>
          <p class="field-hint" style="margin: 0 0 18px; font-size: 0.9375rem;">
            2. Gulir ke bawah lalu pilih <strong>Tambah ke Layar Utama</strong> (Add to Home Screen).
          </p>
        `
            : `
          <p class="field-hint" style="margin: 0 0 10px; font-size: 0.9375rem;">
            1. Buka link aplikasi langsung di browser <strong>Chrome Android</strong> (bukan di dalam preview).
          </p>
          <p class="field-hint" style="margin: 0 0 18px; font-size: 0.9375rem;">
            2. Ketuk menu titik tiga (⋮) di pojok kanan atas, lalu pilih <strong>Tambahkan ke Layar Utama / Instal Aplikasi</strong>.
          </p>
        `
        }
        <div class="form-stack" style="gap: 10px;">
          <button type="button" class="btn btn-secondary btn-full" data-action="copy-app-link">
            <span>Salin Link Aplikasi</span>
          </button>
          <button type="button" class="btn btn-primary btn-full" data-action="close-ios-install">Mengerti</button>
        </div>
      </div>
    </div>
  `;
}

function getActiveChartPoints() {
  return uiState.chartMode === 'flow'
    ? buildDailyFlowSeries(persisted.transactions, uiState.chartRange)
    : buildBalanceSeries(persisted.transactions, uiState.chartRange);
}

function render() {
  const summary = calculateSummary(persisted.transactions, persisted.goal);
  if (uiState.historyMonth !== 'all' && !summary.availableMonths.includes(uiState.historyMonth)) {
    uiState.historyMonth = 'all';
  }
  const newestTx = sortTransactionsNewest(persisted.transactions);
  const chartPoints = getActiveChartPoints();

  let viewHtml = '';
  if (uiState.tab === 'home') {
    viewHtml = renderHomeView(summary, newestTx, chartPoints);
  } else if (uiState.tab === 'history') {
    viewHtml = renderHistoryView(summary, newestTx);
  } else if (uiState.tab === 'goal') {
    viewHtml = renderGoalView(summary, chartPoints);
  } else {
    viewHtml = renderSettingsView(summary);
  }

  appEl.innerHTML = `
    ${renderTopBar()}
    <main class="main-content">
      ${viewHtml}
    </main>
    ${renderBottomNav()}
    ${renderTxSheet(summary)}
    ${renderConfirmSheet()}
    ${renderIOSInstallSheet()}
  `;

  const hasModal = Boolean(uiState.txSheet || uiState.confirmSheet || uiState.iosInstallSheet);
  document.body.classList.toggle('modal-open', hasModal);

  const chartEl = document.getElementById('chart-container');
  if (chartEl) {
    renderSavingsChart(chartEl, chartPoints, uiState.chartSelectedIdx, uiState.chartMode);
  }
}

appEl.addEventListener('click', (e) => {
  const target = e.target;
  if (!(target instanceof Element)) return;

  if (target.id === 'tx-sheet-backdrop') {
    closeTxSheet();
    return;
  }
  if (target.id === 'confirm-sheet-backdrop') {
    uiState.confirmSheet = null;
    render();
    return;
  }
  if (target.id === 'ios-sheet-backdrop') {
    uiState.iosInstallSheet = false;
    render();
    return;
  }

  const navBtn = target.closest('[data-nav]');
  if (navBtn) {
    e.preventDefault();
    const nextTab = navBtn.getAttribute('data-nav');
    if (nextTab && nextTab !== uiState.tab) {
      uiState.tab = nextTab;
      uiState.goalFeedback = null;
      uiState.goalDraft = null;
      uiState.restoreFeedback = null;
      uiState.historyLimit = 50;
      render();
      window.scrollTo({ top: 0, behavior: 'auto' });
    }
    return;
  }

  const chartPt = target.closest('[data-chart-idx]');
  if (chartPt) {
    const idx = parseInt(chartPt.getAttribute('data-chart-idx') || '', 10);
    if (!Number.isNaN(idx)) {
      uiState.chartSelectedIdx = idx;
      renderSavingsChart(
        document.getElementById('chart-container'),
        getActiveChartPoints(),
        uiState.chartSelectedIdx,
        uiState.chartMode
      );
    }
    return;
  }

  const chartModeBtn = target.closest('[data-chart-mode]');
  if (chartModeBtn) {
    uiState.chartMode = chartModeBtn.getAttribute('data-chart-mode') === 'flow' ? 'flow' : 'line';
    uiState.chartSelectedIdx = null;
    render();
    return;
  }

  const rangeBtn = target.closest('[data-chart-range]');
  if (rangeBtn) {
    uiState.chartRange = rangeBtn.getAttribute('data-chart-range') || 'all';
    uiState.chartSelectedIdx = null;
    render();
    return;
  }

  const filterBtn = target.closest('[data-history-filter]');
  if (filterBtn) {
    uiState.historyFilter = filterBtn.getAttribute('data-history-filter') || 'all';
    render();
    return;
  }

  const editBtn = target.closest('[data-edit-tx]');
  if (editBtn) {
    openEditSheet(editBtn.getAttribute('data-edit-tx'));
    return;
  }

  const deleteBtn = target.closest('[data-delete-tx]');
  if (deleteBtn) {
    openConfirmDeleteTx(deleteBtn.getAttribute('data-delete-tx'));
    return;
  }

  const sheetTypeBtn = target.closest('[data-sheet-type]');
  if (sheetTypeBtn && uiState.txSheet) {
    const amountEl = document.getElementById('tx-amount-input');
    const dateEl = document.getElementById('tx-date-input');
    const noteEl = document.getElementById('tx-note-input');
    if (amountEl) uiState.txSheet.amount = parseAmountInput(amountEl.value);
    if (dateEl) uiState.txSheet.date = dateEl.value;
    if (noteEl) uiState.txSheet.note = noteEl.value;
    uiState.txSheet.type = sheetTypeBtn.getAttribute('data-sheet-type') === 'withdraw' ? 'withdraw' : 'deposit';
    uiState.txSheet.error = '';
    render();
    return;
  }

  const quickBtn = target.closest('[data-quick-amount]');
  if (quickBtn && uiState.txSheet) {
    const addVal = parseInt(quickBtn.getAttribute('data-quick-amount') || '0', 10);
    if (addVal > 0) {
      uiState.txSheet.amount = Math.min(MAX_AMOUNT, (uiState.txSheet.amount || 0) + addVal);
      uiState.txSheet.error = '';
      const input = document.getElementById('tx-amount-input');
      if (input) input.value = formatThousands(uiState.txSheet.amount);
      updateTxWarning();
    }
    return;
  }

  const actionBtn = target.closest('[data-action]');
  if (!actionBtn) return;
  const action = actionBtn.getAttribute('data-action');

  switch (action) {
    case 'toggle-theme': {
      const next = isDarkActive() ? 'light' : 'dark';
      persisted.theme = next;
      applyTheme(next);
      persistAndRender(false);
      break;
    }
    case 'toggle-welcome': {
      persisted.welcomeCollapsed = !persisted.welcomeCollapsed;
      persistAndRender(false);
      break;
    }
    case 'toggle-reminder': {
      persisted.reminder.enabled = !persisted.reminder.enabled;
      if (persisted.reminder.enabled) {
        // Allow firing today if user sets a future/current time
        persisted.reminder.lastNotifiedDate = null;
      }
      persistAndRender(false);
      showToast(
        persisted.reminder.enabled
          ? `Pengingat harian aktif jam ${persisted.reminder.time}`
          : 'Pengingat harian dimatikan'
      );
      break;
    }
    case 'request-notification': {
      if ('Notification' in window && Notification.requestPermission) {
        Notification.requestPermission()
          .then((res) => {
            render();
            if (res === 'granted') {
              showToast('Notifikasi browser diizinkan');
            } else {
              showToast('Pengingat tetap aktif melalui toast di aplikasi');
            }
          })
          .catch(() => {
            showToast('Pengingat akan tampil melalui toast di aplikasi');
          });
      }
      break;
    }
    case 'test-reminder':
      triggerReminderPrompt(true);
      break;
    case 'open-add-deposit':
      openAddSheet('deposit');
      break;
    case 'open-add-withdraw':
      openAddSheet('withdraw');
      break;
    case 'close-tx-sheet':
      closeTxSheet();
      break;
    case 'reset-tx-amount':
      if (uiState.txSheet) {
        uiState.txSheet.amount = 0;
        uiState.txSheet.error = '';
        const input = document.getElementById('tx-amount-input');
        if (input) {
          input.value = '';
          input.focus();
        }
        updateTxWarning();
      }
      break;
    case 'close-confirm-sheet':
      uiState.confirmSheet = null;
      render();
      break;
    case 'confirm-action':
      executeConfirmAction();
      break;
    case 'delete-goal':
      uiState.confirmSheet = {
        kind: 'deleteGoal',
        title: 'Hapus Target Tabungan?',
        message: 'Target tabungan akan dihapus, sedangkan saldo dan riwayat transaksi Anda tetap aman.',
        confirmLabel: 'Hapus Target',
      };
      render();
      break;
    case 'install-app':
      if (deferredInstallPrompt) {
        const promptEvent = deferredInstallPrompt;
        deferredInstallPrompt = null;
        Promise.resolve(promptEvent.prompt())
          .then(() => promptEvent.userChoice)
          .then((choice) => {
            if (choice && choice.outcome === 'accepted') {
              showToast('Memasang TabunganSaya...');
            }
            render();
          })
          .catch(() => {
            render();
          });
      }
      break;
    case 'open-ios-install':
      uiState.iosInstallSheet = true;
      render();
      break;
    case 'close-ios-install':
      uiState.iosInstallSheet = false;
      render();
      break;
    case 'copy-app-link': {
      const appUrl = window.location.origin;
      const done = () => showToast('Link aplikasi disalin');
      const fallback = () => {
        try {
          const ta = document.createElement('textarea');
          ta.value = appUrl;
          ta.setAttribute('readonly', '');
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.select();
          const ok = document.execCommand('copy');
          ta.remove();
          if (ok) {
            done();
            return;
          }
        } catch {}
        showToast('Salin URL langsung dari address bar browser');
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(appUrl).then(done).catch(fallback);
      } else {
        fallback();
      }
      break;
    }
    case 'download-offline-app': {
      showToast('Menyiapkan file aplikasi...');
      fetch('/TabunganSaya-App.html')
        .then((res) => {
          if (!res.ok) throw new Error('not_found');
          return res.blob();
        })
        .then((blob) => {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'TabunganSaya.html';
          document.body.appendChild(a);
          a.click();
          a.remove();
          setTimeout(() => URL.revokeObjectURL(url), 5000);
          showToast('File TabunganSaya.html berhasil diunduh');
        })
        .catch(() => {
          showToast('Gagal mengunduh file aplikasi');
        });
      break;
    }
    case 'load-more-history': {
      uiState.historyLimit += 50;
      const container = document.getElementById('history-list-container');
      if (container) {
        container.innerHTML = renderHistoryListOnly(sortTransactionsNewest(persisted.transactions));
      }
      break;
    }
    case 'download-backup': {
      const payloadText = JSON.stringify(createBackupPayload(persisted), null, 2);
      const fileName = `tabungansaya-backup-${getLocalDateString()}.json`;
      if (window.TabunganAndroid && typeof window.TabunganAndroid.saveBackup === 'function') {
        window.TabunganAndroid.saveBackup(fileName, payloadText);
      } else {
        const blob = new Blob([payloadText], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 5000);
        showToast('File backup berhasil diunduh');
      }
      persisted.lastBackupAt = Date.now();
      persisted.changesSinceBackup = 0;
      persistAndRender(false);
      break;
    }
    case 'copy-backup': {
      const payload = JSON.stringify(createBackupPayload(persisted), null, 2);
      const onCopied = () => {
        persisted.lastBackupAt = Date.now();
        persisted.changesSinceBackup = 0;
        persistAndRender(false);
        showToast('Data backup disalin ke clipboard');
      };
      const fallbackCopy = () => {
        try {
          const ta = document.createElement('textarea');
          ta.value = payload;
          ta.setAttribute('readonly', '');
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.select();
          const ok = document.execCommand('copy');
          ta.remove();
          if (ok) {
            onCopied();
            return;
          }
        } catch {}
        showToast('Gagal menyalin, silakan gunakan Unduh Backup');
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(payload).then(onCopied).catch(fallbackCopy);
      } else {
        fallbackCopy();
      }
      break;
    }
    case 'toggle-paste-restore':
      uiState.showPasteRestore = !uiState.showPasteRestore;
      uiState.restoreFeedback = null;
      render();
      break;
    case 'check-paste-restore': {
      const rawText = uiState.pasteRestoreText.trim();
      if (!rawText) {
        uiState.restoreFeedback = { type: 'error', message: 'Tempel teks JSON backup terlebih dahulu.' };
        render();
        return;
      }
      const result = parseAndValidateBackup(rawText);
      if (!result.ok) {
        uiState.pendingRestore = null;
        uiState.restoreFeedback = { type: 'error', message: result.error };
      } else {
        uiState.restoreFeedback = null;
        uiState.pendingRestore = {
          transactions: result.data.transactions,
          goal: result.data.goal,
          fileName: 'Teks JSON Backup',
        };
      }
      render();
      break;
    }
    case 'cancel-restore':
      uiState.pendingRestore = null;
      uiState.restoreFeedback = null;
      render();
      break;
    case 'confirm-restore': {
      if (!uiState.pendingRestore) return;
      persisted.transactions = uiState.pendingRestore.transactions;
      persisted.goal = uiState.pendingRestore.goal;
      persisted.changesSinceBackup = 0;
      uiState.pendingRestore = null;
      uiState.showPasteRestore = false;
      uiState.pasteRestoreText = '';
      uiState.lastDeletedTx = null;
      uiState.chartSelectedIdx = null;
      uiState.historyMonth = 'all';
      uiState.historyQuery = '';
      uiState.goalDraft = null;
      uiState.restoreFeedback = {
        type: 'success',
        message: `Data berhasil dipulihkan (${persisted.transactions.length} transaksi).`,
      };
      persistAndRender(false);
      showToast('Data berhasil dipulihkan');
      break;
    }
  }
});

function updateTxWarning() {
  if (!uiState.txSheet) return;
  const slot = document.getElementById('tx-warning-slot');
  if (!slot) return;
  let totalBalance = 0;
  for (const t of persisted.transactions) {
    totalBalance += t.type === 'deposit' ? t.amount : -t.amount;
  }
  let editableBalance = totalBalance;
  if (uiState.txSheet.mode === 'edit') {
    const orig = persisted.transactions.find((t) => t.id === uiState.txSheet.editId);
    if (orig) {
      editableBalance =
        orig.type === 'deposit'
          ? totalBalance - orig.amount
          : totalBalance + orig.amount;
    }
  }
  if (
    uiState.txSheet.type === 'withdraw' &&
    uiState.txSheet.amount > 0 &&
    uiState.txSheet.amount > editableBalance
  ) {
    slot.innerHTML = `<div class="inline-alert is-warning">Nominal melebihi saldo saat ini (${escapeHtml(formatRupiah(editableBalance))}).</div>`;
  } else {
    slot.innerHTML = '';
  }
}

appEl.addEventListener('input', (e) => {
  const target = e.target;

  if (target instanceof HTMLTextAreaElement && target.id === 'paste-restore-input') {
    uiState.pasteRestoreText = target.value;
    return;
  }

  if (!(target instanceof HTMLInputElement)) return;

  if (target.id === 'history-search-input') {
    uiState.historyQuery = target.value;
    const container = document.getElementById('history-list-container');
    if (container) {
      container.innerHTML = renderHistoryListOnly(sortTransactionsNewest(persisted.transactions));
    }
    return;
  }

  if (target.id === 'tx-amount-input' && uiState.txSheet) {
    const amount = formatAmountInputPreserveCaret(target);
    uiState.txSheet.amount = amount;
    uiState.txSheet.error = '';
    updateTxWarning();
    return;
  }

  if (target.id === 'tx-date-input' && uiState.txSheet) {
    uiState.txSheet.date = target.value;
    return;
  }

  if (target.id === 'tx-note-input' && uiState.txSheet) {
    uiState.txSheet.note = target.value;
    return;
  }

  if (target.id === 'goal-name-input') {
    const amountEl = document.getElementById('goal-amount-input');
    uiState.goalDraft = {
      name: target.value,
      amount: parseAmountInput(amountEl?.value || ''),
    };
    return;
  }

  if (target.id === 'goal-amount-input') {
    const amount = formatAmountInputPreserveCaret(target);
    const nameEl = document.getElementById('goal-name-input');
    uiState.goalDraft = {
      name: nameEl ? nameEl.value : persisted.goal?.name || '',
      amount,
    };
  }
});

// Fix backspace right after a thousand separator dot on amount inputs
appEl.addEventListener('keydown', (e) => {
  const target = e.target;
  if (!(target instanceof HTMLInputElement)) return;
  if (target.id !== 'tx-amount-input' && target.id !== 'goal-amount-input') return;
  if (e.key !== 'Backspace') return;

  const start = target.selectionStart ?? 0;
  const end = target.selectionEnd ?? 0;
  if (start === end && start > 1 && target.value[start - 1] === '.') {
    e.preventDefault();
    const before = target.value.slice(0, start - 2);
    const after = target.value.slice(start);
    target.value = before + after;
    try {
      target.setSelectionRange(Math.max(0, start - 2), Math.max(0, start - 2));
    } catch {}
    target.dispatchEvent(new Event('input', { bubbles: true }));
  }
});

appEl.addEventListener('change', (e) => {
  const target = e.target;

  if (target instanceof HTMLSelectElement && target.id === 'history-month-select') {
    uiState.historyMonth = target.value || 'all';
    const container = document.getElementById('history-list-container');
    if (container) {
      container.innerHTML = renderHistoryListOnly(sortTransactionsNewest(persisted.transactions));
    }
    return;
  }

  if (!(target instanceof HTMLInputElement)) return;

  if (target.id === 'tx-date-input' && uiState.txSheet) {
    uiState.txSheet.date = target.value;
    return;
  }

  if (target.id === 'reminder-time-input') {
    const val = target.value;
    if (/^([01]\d|2[0-3]):[0-5]\d$/.test(val)) {
      persisted.reminder.time = val;
      persisted.reminder.lastNotifiedDate = null;
      persistAndRender(false);
      showToast(`Jam pengingat diubah ke ${val}`);
    }
    return;
  }

  if (target.id === 'restore-file-input' && target.files && target.files[0]) {
    const file = target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      const result = parseAndValidateBackup(String(reader.result || ''));
      if (!result.ok) {
        uiState.pendingRestore = null;
        uiState.restoreFeedback = { type: 'error', message: result.error };
      } else {
        uiState.restoreFeedback = null;
        uiState.pendingRestore = {
          transactions: result.data.transactions,
          goal: result.data.goal,
          fileName: file.name,
        };
      }
      render();
    };
    reader.onerror = () => {
      uiState.pendingRestore = null;
      uiState.restoreFeedback = { type: 'error', message: 'Gagal membaca file dari perangkat.' };
      render();
    };
    reader.readAsText(file);
    target.value = '';
  }
});

appEl.addEventListener('submit', (e) => {
  const form = e.target;
  if (!(form instanceof HTMLFormElement)) return;
  e.preventDefault();

  if (form.id === 'tx-form' && uiState.txSheet) {
    const sheet = uiState.txSheet;
    const amount = parseAmountInput(document.getElementById('tx-amount-input')?.value || sheet.amount);
    const dateVal = (document.getElementById('tx-date-input')?.value || sheet.date || '').trim();
    const noteVal = (document.getElementById('tx-note-input')?.value || '').trim().slice(0, 120);

    sheet.amount = amount;
    sheet.date = dateVal;
    sheet.note = noteVal;

    if (!amount || amount <= 0) {
      sheet.error = 'Masukkan nominal uang lebih dari Rp0.';
      render();
      focusAmountInput();
      return;
    }

    if (!isValidCalendarDate(dateVal)) {
      sheet.error = 'Pilih tanggal transaksi yang valid terlebih dahulu.';
      render();
      return;
    }

    const now = Date.now();
    if (sheet.mode === 'edit' && sheet.editId) {
      const idx = persisted.transactions.findIndex((t) => t.id === sheet.editId);
      if (idx !== -1) {
        persisted.transactions[idx] = {
          ...persisted.transactions[idx],
          type: sheet.type,
          amount,
          date: dateVal,
          note: noteVal,
          updatedAt: now,
        };
      }
      uiState.txSheet = null;
      uiState.chartSelectedIdx = null;
      persistAndRender(true);
      showToast('Transaksi diperbarui');
    } else {
      persisted.transactions.push({
        id: createId(),
        type: sheet.type,
        amount,
        date: dateVal,
        note: noteVal,
        createdAt: now,
        updatedAt: now,
      });
      uiState.txSheet = null;
      uiState.chartSelectedIdx = null;
      persistAndRender(true);
      showToast(sheet.type === 'deposit' ? 'Tabungan berhasil dicatat' : 'Pengambilan berhasil dicatat');
    }
    return;
  }

  if (form.id === 'goal-form') {
    const nameInput = document.getElementById('goal-name-input');
    const amountInput = document.getElementById('goal-amount-input');
    const rawName = (nameInput?.value || '').trim();
    const name = rawName.slice(0, 60) || 'Target Tabungan';
    const targetAmount = parseAmountInput(amountInput?.value || '');

    if (!targetAmount || targetAmount <= 0) {
      uiState.goalDraft = {
        name: nameInput?.value || '',
        amount: targetAmount,
      };
      uiState.goalFeedback = {
        type: 'error',
        message: 'Masukkan nominal target lebih dari Rp0.',
      };
      render();
      return;
    }

    persisted.goal = { name, targetAmount };
    uiState.goalDraft = null;
    uiState.goalFeedback = {
      type: 'success',
      message: 'Target tabungan berhasil disimpan.',
    };
    persistAndRender(true);
    showToast('Target tabungan diperbarui');
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (uiState.iosInstallSheet) {
      uiState.iosInstallSheet = false;
      render();
      return;
    }
    if (uiState.confirmSheet) {
      uiState.confirmSheet = null;
      render();
      return;
    }
    if (uiState.txSheet) {
      closeTxSheet();
      return;
    }
  }

  if ((e.key === 'Enter' || e.key === ' ') && e.target instanceof Element) {
    const chartPt = e.target.closest('[data-chart-idx]');
    if (chartPt) {
      e.preventDefault();
      const idx = parseInt(chartPt.getAttribute('data-chart-idx') || '', 10);
      if (!Number.isNaN(idx)) {
        uiState.chartSelectedIdx = idx;
        renderSavingsChart(
          document.getElementById('chart-container'),
          getActiveChartPoints(),
          idx,
          uiState.chartMode
        );
      }
    }
  }
});

function showBrowserNotification(title, body) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  try {
    if ('serviceWorker' in navigator && navigator.serviceWorker.getRegistration) {
      navigator.serviceWorker
        .getRegistration()
        .then((reg) => {
          if (reg && reg.showNotification) {
            reg.showNotification(title, {
              body,
              icon: '/pwa-192x192.png',
              tag: 'tabungansaya-daily-reminder',
            });
          } else {
            new Notification(title, { body, icon: '/pwa-192x192.png' });
          }
        })
        .catch(() => {
          try {
            new Notification(title, { body, icon: '/pwa-192x192.png' });
          } catch {}
        });
    } else {
      new Notification(title, { body, icon: '/pwa-192x192.png' });
    }
  } catch {}
}

function triggerReminderPrompt(isTest = false) {
  const title = 'Waktunya Menabung!';
  const body = isTest
    ? 'Contoh pengingat harian: jangan lupa catat uang tabungan hari ini.'
    : 'Jangan lupa catat uang tabungan atau celengan Anda hari ini.';

  showBrowserNotification(title, body);
  showToast('Waktunya catat tabungan hari ini!', null, {
    label: 'Catat',
    onClick: () => openAddSheet('deposit'),
  });
}

function checkDailyReminder() {
  const r = persisted.reminder;
  if (!r || !r.enabled) return;

  const now = new Date();
  const todayStr = getLocalDateString(now);
  if (r.lastNotifiedDate === todayStr) return;

  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  const currentHHMM = `${hh}:${mm}`;

  if (currentHHMM >= r.time) {
    persisted.reminder.lastNotifiedDate = todayStr;
    saveState(persisted);
    triggerReminderPrompt(false);
  }
}

applyTheme(persisted.theme);
render();

setTimeout(checkDailyReminder, 1500);
setInterval(checkDailyReminder, 30000);
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    checkDailyReminder();
  }
});
