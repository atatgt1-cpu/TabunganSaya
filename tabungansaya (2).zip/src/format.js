const MONTHS_SHORT = [
  'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
  'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des',
];

const DAYS_SHORT = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
const DAYS_FULL = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

/**
 * Format integer amount as Indonesian Rupiah, e.g. "Rp10.000" or "-Rp10.000"
 */
export function formatRupiah(amount) {
  const num = Number(amount) || 0;
  const abs = Math.abs(Math.round(num));
  const formatted = abs.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return num < 0 ? `-Rp${formatted}` : `Rp${formatted}`;
}

/**
 * Format plain integer with thousand dots for input display, e.g. 10000 -> "10.000"
 */
export function formatThousands(amount) {
  const num = Math.abs(Math.round(Number(amount) || 0));
  if (num === 0) return '';
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

/**
 * Compact Rupiah label for chart axis, e.g. 1500000 -> "1,5 jt", 25000 -> "25 rb"
 */
export function formatCompactRupiah(amount) {
  const num = Number(amount) || 0;
  const sign = num < 0 ? '-' : '';
  const abs = Math.abs(num);
  if (abs >= 999_950_000) {
    const val = (abs / 1_000_000_000).toFixed(1).replace(/\.0$/, '').replace('.', ',');
    return `${sign}${val} M`;
  }
  if (abs >= 999_500) {
    const val = (abs / 1_000_000).toFixed(1).replace(/\.0$/, '').replace('.', ',');
    return `${sign}${val} jt`;
  }
  if (abs >= 1_000) {
    const val = Math.round(abs / 1_000);
    return `${sign}${val} rb`;
  }
  return `${sign}${Math.round(abs)}`;
}

export const MAX_AMOUNT = 999_999_999_999;

/**
 * Parse digits from user input string into positive integer (capped safely)
 */
export function parseAmountInput(value) {
  const digits = String(value || '').replace(/[^\d]/g, '');
  if (!digits) return 0;
  const parsed = parseInt(digits.slice(0, 12), 10);
  if (!Number.isFinite(parsed)) return 0;
  return Math.min(MAX_AMOUNT, parsed);
}

/**
 * Format an amount input element while preserving caret position across thousand dots
 */
export function formatAmountInputPreserveCaret(inputEl) {
  const raw = inputEl.value;
  const caret = inputEl.selectionStart ?? raw.length;
  let digitsBefore = 0;
  for (let i = 0; i < caret; i++) {
    if (/\d/.test(raw[i])) digitsBefore += 1;
  }

  const amount = parseAmountInput(raw);
  const formatted = formatThousands(amount);
  inputEl.value = formatted;

  if (document.activeElement === inputEl && typeof inputEl.setSelectionRange === 'function') {
    let seenDigits = 0;
    let nextPos = formatted.length;
    for (let i = 0; i < formatted.length; i++) {
      if (seenDigits >= digitsBefore) {
        nextPos = i;
        break;
      }
      if (/\d/.test(formatted[i])) seenDigits += 1;
    }
    if (digitsBefore === 0) nextPos = 0;
    try {
      inputEl.setSelectionRange(nextPos, nextPos);
    } catch {}
  }

  return amount;
}

/**
 * Return local YYYY-MM-DD string for today (or a given Date)
 */
export function getLocalDateString(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Strictly validate YYYY-MM-DD against real calendar dates (e.g. rejects 2026-02-31)
 */
export function isValidCalendarDate(dateStr) {
  if (typeof dateStr !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return false;
  const parts = dateStr.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const day = parseInt(parts[2], 10);
  if (month < 1 || month > 12 || day < 1 || day > 31) return false;
  const d = new Date(year, month - 1, day);
  return (
    d.getFullYear() === year &&
    d.getMonth() === month - 1 &&
    d.getDate() === day
  );
}

/**
 * Format YYYY-MM-DD into human Indonesian label ("Hari ini", "Kemarin", or "15 Nov 2026")
 */
export function formatDateLabel(dateStr, includeRelative = true) {
  if (!isValidCalendarDate(dateStr)) return dateStr && typeof dateStr === 'string' ? dateStr : '-';
  const parts = dateStr.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);

  if (includeRelative) {
    const today = getLocalDateString();
    if (dateStr === today) return 'Hari ini';

    const yesterdayDate = new Date();
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    if (dateStr === getLocalDateString(yesterdayDate)) return 'Kemarin';
  }

  const monthName = MONTHS_SHORT[month] || '';
  return `${day} ${monthName} ${year}`;
}

/**
 * Short date format for chart labels, e.g. "15 Nov"
 */
export function formatShortDate(dateStr) {
  if (!isValidCalendarDate(dateStr)) return String(dateStr || '');
  const parts = dateStr.split('-');
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);
  return `${day} ${MONTHS_SHORT[month] || ''}`;
}

/**
 * Short Indonesian day name for YYYY-MM-DD, e.g. "Min", "Sen"
 */
export function formatDayShort(dateStr) {
  if (!isValidCalendarDate(dateStr)) return '';
  const parts = dateStr.split('-');
  const d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
  return DAYS_SHORT[d.getDay()] || '';
}

/**
 * Full Indonesian day + date label, e.g. "Minggu, 15 Nov 2026" or "Hari ini (Min, 15 Nov)"
 */
export function formatDayDateLabel(dateStr, includeRelative = true) {
  if (!isValidCalendarDate(dateStr)) return dateStr && typeof dateStr === 'string' ? dateStr : '-';
  const parts = dateStr.split('-');
  const year = parseInt(parts[0], 10);
  const monthIdx = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);
  const d = new Date(year, monthIdx, day);
  const dayShort = DAYS_SHORT[d.getDay()] || '';
  const dayFull = DAYS_FULL[d.getDay()] || '';
  const monthName = MONTHS_SHORT[monthIdx] || '';

  if (includeRelative) {
    const today = getLocalDateString();
    if (dateStr === today) return `Hari ini (${dayShort}, ${day} ${monthName})`;

    const yesterdayDate = new Date();
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    if (dateStr === getLocalDateString(yesterdayDate)) {
      return `Kemarin (${dayShort}, ${day} ${monthName})`;
    }
  }

  return `${dayFull}, ${day} ${monthName} ${year}`;
}

/**
 * Format YYYY-MM into Indonesian month-year label, e.g. "Nov 2026"
 */
export function formatMonthLabel(ym) {
  const parts = String(ym || '').split('-');
  if (parts.length !== 2) return ym;
  const year = parts[0];
  const monthIdx = parseInt(parts[1], 10) - 1;
  return `${MONTHS_SHORT[monthIdx] || parts[1]} ${year}`;
}

/**
 * Format epoch timestamp into human date/time for last backup indicator
 */
export function formatBackupDate(ms) {
  if (!ms || !Number.isFinite(Number(ms))) return '';
  const d = new Date(Number(ms));
  if (Number.isNaN(d.getTime())) return '';
  const day = d.getDate();
  const month = MONTHS_SHORT[d.getMonth()] || '';
  const year = d.getFullYear();
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${day} ${month} ${year}, ${hh}:${mm}`;
}

/**
 * Escape HTML special characters before interpolating user text
 */
export function escapeHtml(text) {
  return String(text ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

let idCounter = 0;

/**
 * Generate lightweight unique local ID
 */
export function createId() {
  idCounter = (idCounter + 1) % 10000;
  const rand = Math.random().toString(36).slice(2, 6);
  return `tx_${Date.now()}_${idCounter}_${rand}`;
}
