import { createId, getLocalDateString, isValidCalendarDate, MAX_AMOUNT } from './format.js';

export const STORAGE_KEY = 'tabungansaya_v1';

const DEFAULT_REMINDER = {
  enabled: false,
  time: '20:00',
  lastNotifiedDate: null,
};

function createDefaultState() {
  return {
    version: 1,
    transactions: [],
    goal: null,
    theme: null,
    lastBackupAt: null,
    changesSinceBackup: 0,
    reminder: { ...DEFAULT_REMINDER },
    welcomeCollapsed: false,
  };
}

function sanitizeReminder(raw) {
  if (!raw || typeof raw !== 'object') return { ...DEFAULT_REMINDER };
  const enabled = Boolean(raw.enabled);
  const time = typeof raw.time === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(raw.time)
    ? raw.time
    : '20:00';
  const lastNotifiedDate = isValidCalendarDate(raw.lastNotifiedDate) ? raw.lastNotifiedDate : null;
  return { enabled, time, lastNotifiedDate };
}

function isValidDateStr(str) {
  return isValidCalendarDate(str);
}

function deduplicateTransactionIds(transactions) {
  const seen = new Set();
  return transactions.map((tx) => {
    let id = tx.id;
    while (seen.has(id)) {
      id = createId();
    }
    seen.add(id);
    return id === tx.id ? tx : { ...tx, id };
  });
}

function sanitizeTransaction(raw, strictDate = false) {
  if (!raw || typeof raw !== 'object') return null;
  const type = raw.type === 'withdraw' ? 'withdraw' : raw.type === 'deposit' ? 'deposit' : null;
  const amount = Math.round(Number(raw.amount));
  if (!type || !Number.isFinite(amount) || amount <= 0 || amount > MAX_AMOUNT) return null;
  if (strictDate && !isValidDateStr(raw.date)) return null;

  const date = isValidDateStr(raw.date) ? raw.date : getLocalDateString();
  const note = typeof raw.note === 'string' ? raw.note.trim().slice(0, 120) : '';
  const createdAt = Number.isFinite(Number(raw.createdAt)) ? Number(raw.createdAt) : Date.now();
  const updatedAt = Number.isFinite(Number(raw.updatedAt)) ? Number(raw.updatedAt) : createdAt;

  return {
    id: typeof raw.id === 'string' && raw.id.trim() ? raw.id.trim() : createId(),
    type,
    amount,
    date,
    note,
    createdAt,
    updatedAt,
  };
}

function sanitizeGoal(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const targetAmount = Math.round(Number(raw.targetAmount));
  if (!Number.isFinite(targetAmount) || targetAmount <= 0 || targetAmount > MAX_AMOUNT) return null;
  const name = typeof raw.name === 'string' && raw.name.trim()
    ? raw.name.trim().slice(0, 60)
    : 'Target Tabungan';
  return { name, targetAmount };
}

export function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createDefaultState();
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') {
      return createDefaultState();
    }
    const rawTransactions = Array.isArray(parsed.transactions)
      ? parsed.transactions.map((item) => sanitizeTransaction(item, false)).filter(Boolean)
      : [];
    const transactions = deduplicateTransactionIds(rawTransactions);
    const goal = sanitizeGoal(parsed.goal);
    const theme = parsed.theme === 'dark' || parsed.theme === 'light' ? parsed.theme : null;
    const lastBackupAt = Number.isFinite(Number(parsed.lastBackupAt)) ? Number(parsed.lastBackupAt) : null;
    const changesSinceBackup = Number.isFinite(Number(parsed.changesSinceBackup))
      ? Math.max(0, Math.round(Number(parsed.changesSinceBackup)))
      : 0;
    const reminder = sanitizeReminder(parsed.reminder);
    const welcomeCollapsed = Boolean(parsed.welcomeCollapsed);

    return {
      version: 1,
      transactions,
      goal,
      theme,
      lastBackupAt,
      changesSinceBackup,
      reminder,
      welcomeCollapsed,
    };
  } catch {
    return createDefaultState();
  }
}

export function saveState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      version: 1,
      transactions: state.transactions,
      goal: state.goal,
      theme: state.theme,
      lastBackupAt: state.lastBackupAt,
      changesSinceBackup: state.changesSinceBackup,
      reminder: state.reminder,
      welcomeCollapsed: Boolean(state.welcomeCollapsed),
    }));
    return true;
  } catch {
    return false;
  }
}

/**
 * Sort newest first (by date DESC, then createdAt DESC)
 */
export function sortTransactionsNewest(transactions) {
  return [...transactions].sort((a, b) => {
    if (a.date !== b.date) return b.date.localeCompare(a.date);
    return b.createdAt - a.createdAt;
  });
}

/**
 * Sort oldest first (by date ASC, then createdAt ASC)
 */
export function sortTransactionsOldest(transactions) {
  return [...transactions].sort((a, b) => {
    if (a.date !== b.date) return a.date.localeCompare(b.date);
    return a.createdAt - b.createdAt;
  });
}

/**
 * Core calculation rule:
 * Total saldo = seluruh tabungan masuk - seluruh uang yang diambil.
 * Target tabungan NEVER adds to total saldo.
 */
export function calculateSummary(transactions, goal) {
  let totalDeposit = 0;
  let totalWithdraw = 0;
  let depositCount = 0;
  let withdrawCount = 0;

  const currentMonth = getLocalDateString().slice(0, 7);
  let monthDeposit = 0;
  let monthWithdraw = 0;
  const monthSavingDates = new Set();
  const monthsSet = new Set();

  for (const tx of transactions) {
    const ym = tx.date ? tx.date.slice(0, 7) : '';
    if (ym) monthsSet.add(ym);

    if (tx.type === 'deposit') {
      totalDeposit += tx.amount;
      depositCount += 1;
      if (ym === currentMonth) {
        monthDeposit += tx.amount;
        monthSavingDates.add(tx.date);
      }
    } else if (tx.type === 'withdraw') {
      totalWithdraw += tx.amount;
      withdrawCount += 1;
      if (ym === currentMonth) {
        monthWithdraw += tx.amount;
      }
    }
  }

  const totalBalance = totalDeposit - totalWithdraw;
  const availableMonths = Array.from(monthsSet).sort((a, b) => b.localeCompare(a));

  let goalStats = null;
  if (goal && goal.targetAmount > 0) {
    const positiveBalance = Math.max(0, totalBalance);
    const rawPercent = (positiveBalance / goal.targetAmount) * 100;
    const percent = Math.min(100, Math.round(rawPercent));
    const remaining = Math.max(0, goal.targetAmount - positiveBalance);
    const isAchieved = totalBalance >= goal.targetAmount;
    goalStats = {
      name: goal.name,
      targetAmount: goal.targetAmount,
      currentAmount: positiveBalance,
      percent,
      remaining,
      isAchieved,
    };
  }

  return {
    totalDeposit,
    totalWithdraw,
    totalBalance,
    depositCount,
    withdrawCount,
    totalCount: transactions.length,
    monthDeposit,
    monthWithdraw,
    monthSavingDays: monthSavingDates.size,
    availableMonths,
    goalStats,
  };
}

/**
 * Build chronological per-transaction balance series (shows every up/down move, including same-day)
 */
export function buildBalanceSeries(transactions, range = 'all') {
  if (!transactions.length) return [];

  const sorted = sortTransactionsOldest(transactions);
  let running = 0;
  const allSteps = sorted.map((tx) => {
    const delta = tx.type === 'deposit' ? tx.amount : -tx.amount;
    running += delta;
    return {
      id: tx.id,
      date: tx.date,
      type: tx.type,
      note: tx.note || '',
      delta,
      balance: running,
      isBaseline: false,
    };
  });

  if (range === 'all') {
    const firstDate = allSteps[0].date;
    return [
      { id: 'base', date: firstDate, type: 'baseline', note: 'Saldo awal', delta: 0, balance: 0, isBaseline: true },
      ...allSteps,
    ];
  }

  const days = range === '7d' ? 7 : 30;
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - (days - 1));
  const cutoffStr = getLocalDateString(cutoffDate);

  const firstIdxInWindow = allSteps.findIndex((s) => s.date >= cutoffStr);
  if (firstIdxInWindow === -1) {
    const sliceStart = Math.max(0, allSteps.length - 8);
    const prevBal = sliceStart > 0 ? allSteps[sliceStart - 1].balance : 0;
    const sliced = allSteps.slice(sliceStart);
    return [
      { id: 'base', date: sliced[0].date, type: 'baseline', note: 'Saldo sebelumnya', delta: 0, balance: prevBal, isBaseline: true },
      ...sliced,
    ];
  }

  const prevBal = firstIdxInWindow > 0 ? allSteps[firstIdxInWindow - 1].balance : 0;
  const sliced = allSteps.slice(firstIdxInWindow);
  return [
    { id: 'base', date: sliced[0].date, type: 'baseline', note: 'Saldo awal periode', delta: 0, balance: prevBal, isBaseline: true },
    ...sliced,
  ];
}

/**
 * Build daily inflow/outflow series for diverging up/down bar chart
 */
export function buildDailyFlowSeries(transactions, range = 'all') {
  if (!transactions.length) return [];

  const sorted = sortTransactionsOldest(transactions);
  const dailyMap = new Map();

  for (const tx of sorted) {
    const cur = dailyMap.get(tx.date) || { date: tx.date, deposit: 0, withdraw: 0, net: 0 };
    if (tx.type === 'deposit') {
      cur.deposit += tx.amount;
      cur.net += tx.amount;
    } else {
      cur.withdraw += tx.amount;
      cur.net -= tx.amount;
    }
    dailyMap.set(tx.date, cur);
  }

  const allDays = Array.from(dailyMap.values());
  if (range === 'all' || allDays.length <= 1) return allDays;

  const days = range === '7d' ? 7 : 30;
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - (days - 1));
  const cutoffStr = getLocalDateString(cutoffDate);

  const filtered = allDays.filter((d) => d.date >= cutoffStr);
  return filtered.length > 0 ? filtered : allDays.slice(-Math.min(allDays.length, 7));
}

export function createBackupPayload(state) {
  return {
    app: 'TabunganSaya',
    version: 1,
    exportedAt: new Date().toISOString(),
    transactions: state.transactions,
    goal: state.goal,
  };
}

export function parseAndValidateBackup(jsonText) {
  let parsed;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    return { ok: false, error: 'File bukan format JSON yang valid.' };
  }

  if (!parsed || typeof parsed !== 'object') {
    return { ok: false, error: 'Struktur data backup tidak dikenali.' };
  }

  if (!Array.isArray(parsed.transactions)) {
    return { ok: false, error: 'Data transaksi tidak ditemukan di dalam file backup.' };
  }

  const sanitizedTransactions = [];
  for (const item of parsed.transactions) {
    const valid = sanitizeTransaction(item, true);
    if (!valid) {
      return { ok: false, error: 'Terdapat data transaksi yang rusak atau tidak valid di file backup.' };
    }
    sanitizedTransactions.push(valid);
  }

  const sanitizedGoal =
    parsed.goal !== null && parsed.goal !== undefined ? sanitizeGoal(parsed.goal) : null;
  if (parsed.goal !== null && parsed.goal !== undefined && !sanitizedGoal) {
    return { ok: false, error: 'Data target tabungan di dalam file backup tidak valid.' };
  }

  return {
    ok: true,
    data: {
      transactions: deduplicateTransactionIds(sanitizedTransactions),
      goal: sanitizedGoal,
    },
  };
}
