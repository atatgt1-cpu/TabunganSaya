import {
  escapeHtml,
  formatCompactRupiah,
  formatDateLabel,
  formatDayDateLabel,
  formatDayShort,
  formatRupiah,
  formatShortDate,
} from './format.js';

function niceCeil(val) {
  if (!Number.isFinite(val) || val <= 0) return 1000;
  const exp = Math.floor(Math.log10(val));
  const pow = Math.pow(10, exp);
  const frac = val / pow;
  let niceFrac = 10;
  if (frac <= 1) niceFrac = 1;
  else if (frac <= 1.2) niceFrac = 1.2;
  else if (frac <= 1.5) niceFrac = 1.5;
  else if (frac <= 2) niceFrac = 2;
  else if (frac <= 2.5) niceFrac = 2.5;
  else if (frac <= 3) niceFrac = 3;
  else if (frac <= 4) niceFrac = 4;
  else if (frac <= 5) niceFrac = 5;
  else if (frac <= 6) niceFrac = 6;
  else if (frac <= 8) niceFrac = 8;
  return Math.round(niceFrac * pow);
}

function buildDayDateXLabels(items, getX, getDate, padLeft, width, padRight) {
  if (!items.length) return [];

  const uniqueDates = new Set(items.map(getDate));
  if (uniqueDates.size === 1) {
    const dateStr = getDate(items[0]);
    const plotW = width - padLeft - padRight;
    return [
      {
        x: padLeft + plotW / 2,
        anchor: 'middle',
        day: formatDayShort(dateStr),
        date: formatShortDate(dateStr),
      },
    ];
  }

  const minSpacing = 46;
  const selected = [];

  const maxLabels = Math.min(5, items.length);
  const candidateIndices = new Set([0, items.length - 1]);
  if (maxLabels > 2) {
    for (let i = 1; i < maxLabels - 1; i++) {
      candidateIndices.add(Math.round((i / (maxLabels - 1)) * (items.length - 1)));
    }
  }
  const sortedIndices = Array.from(candidateIndices).sort((a, b) => a - b);

  for (const idx of sortedIndices) {
    const item = items[idx];
    const x = getX(item);
    const isLast = idx === items.length - 1;
    if (selected.length === 0) {
      selected.push(item);
      continue;
    }
    const prev = selected[selected.length - 1];
    const prevX = getX(prev);
    const sameLabel = getDate(prev) === getDate(item);
    if (isLast) {
      if (sameLabel) continue;
      if (x - prevX < minSpacing && selected.length > 1) {
        selected.pop();
      }
      const newPrev = selected[selected.length - 1];
      if (getDate(newPrev) !== getDate(item) && x - getX(newPrev) >= minSpacing) {
        selected.push(item);
      }
    } else if (!sameLabel && x - prevX >= minSpacing) {
      selected.push(item);
    }
  }

  return selected.map((item) => {
    const x = getX(item);
    const dateStr = getDate(item);
    let anchor = 'middle';
    if (selected.length > 1) {
      if (x <= padLeft + 18) anchor = 'start';
      else if (x >= width - padRight - 18) anchor = 'end';
    }
    return {
      x,
      anchor,
      day: formatDayShort(dateStr),
      date: formatShortDate(dateStr),
    };
  });
}

function renderXLabelsSvg(xLabels, baselineY) {
  const dayY = baselineY + 13;
  const dateY = baselineY + 24;
  return xLabels
    .map(
      (xl) => `
      <text x="${xl.x.toFixed(1)}" y="${dayY.toFixed(1)}" text-anchor="${xl.anchor}" class="chart-axis-day">${escapeHtml(xl.day)}</text>
      <text x="${xl.x.toFixed(1)}" y="${dateY.toFixed(1)}" text-anchor="${xl.anchor}" class="chart-axis-text">${escapeHtml(xl.date)}</text>
    `
    )
    .join('');
}

/**
 * Render lightweight responsive SVG savings up/down chart.
 * mode = 'line' (Saldo naik-turun hijau/merah per transaksi)
 * mode = 'flow' (Batang naik masuk / turun keluar harian dari garis 0)
 */
export function renderSavingsChart(container, points, selectedIndex = null, mode = 'line') {
  if (!container) return;

  if (!points || points.length === 0) {
    container.innerHTML = `
      <div class="chart-empty">
        <p class="chart-empty-title">Belum ada data grafik</p>
        <p class="chart-empty-sub">Catat tabungan atau pengambilan pertama Anda untuk melihat grafik naik turun.</p>
      </div>
    `;
    return;
  }

  if (mode === 'flow') {
    renderFlowBarChart(container, points, selectedIndex);
  } else {
    renderBalanceLineChart(container, points, selectedIndex);
  }
}

function renderBalanceLineChart(container, points, selectedIndex) {
  const activeIdx =
    selectedIndex !== null && selectedIndex >= 0 && selectedIndex < points.length
      ? selectedIndex
      : points.length - 1;

  const activePoint = points[activeIdx];
  const balances = points.map((p) => p.balance);
  const rawMin = Math.min(...balances, 0);
  const rawMax = Math.max(...balances, 0);

  let yMin = 0;
  let yMax = niceCeil(rawMax > 0 ? rawMax * 1.08 : 10000);
  if (rawMin < 0) {
    yMin = -niceCeil(Math.abs(rawMin) * 1.08);
    if (rawMax === 0) yMax = 0;
  }
  const ySpan = yMax - yMin || 1;

  const width = 340;
  const height = 186;
  const padLeft = 52;
  const padRight = 14;
  const padTop = 14;
  const padBottom = 34;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;
  const baselineY = padTop + plotH;

  const coords = points.map((pt, idx) => {
    const x =
      points.length === 1
        ? padLeft + plotW / 2
        : padLeft + (idx / (points.length - 1)) * plotW;
    const ratio = (pt.balance - yMin) / ySpan;
    const y = padTop + plotH - ratio * plotH;
    return { x, y, pt, idx };
  });

  const zeroY = padTop + plotH - ((0 - yMin) / ySpan) * plotH;
  const hasNegative = rawMin < 0;
  const showZeroLine = hasNegative && zeroY >= padTop && zeroY <= baselineY;

  const segmentsSvg = coords
    .slice(1)
    .map((curr, i) => {
      const prev = coords[i];
      const isUp = curr.pt.balance >= prev.pt.balance;
      const segClass = isUp ? 'chart-seg-up' : 'chart-seg-down';
      return `<line x1="${prev.x.toFixed(1)}" y1="${prev.y.toFixed(1)}" x2="${curr.x.toFixed(1)}" y2="${curr.y.toFixed(1)}" class="${segClass}" />`;
    })
    .join('');

  const linePath = coords
    .map((c, i) => `${i === 0 ? 'M' : 'L'} ${c.x.toFixed(1)} ${c.y.toFixed(1)}`)
    .join(' ');

  const areaPath =
    coords.length > 1 && !hasNegative
      ? `${linePath} L ${coords[coords.length - 1].x.toFixed(1)} ${baselineY.toFixed(1)} L ${coords[0].x.toFixed(1)} ${baselineY.toFixed(1)} Z`
      : '';

  const midVal = (yMax + yMin) / 2;
  const ticks = [
    { val: yMax, y: padTop },
    { val: midVal, y: padTop + plotH / 2 },
    { val: yMin, y: baselineY },
  ];

  const gridSvg = ticks
    .map(
      (t) => `
      <line x1="${padLeft}" y1="${t.y.toFixed(1)}" x2="${width - padRight}" y2="${t.y.toFixed(1)}" class="chart-grid-line" />
      <text x="${padLeft - 6}" y="${(t.y + 3.5).toFixed(1)}" text-anchor="end" class="chart-axis-text">${escapeHtml(formatCompactRupiah(t.val))}</text>
    `
    )
    .join('');

  const labelSource =
    coords.length > 1 && coords[0].pt.isBaseline && coords[0].pt.date === coords[1].pt.date
      ? coords.slice(1)
      : coords;
  const xLabels = buildDayDateXLabels(
    labelSource,
    (c) => (labelSource.length === 1 ? padLeft + plotW / 2 : c.x),
    (c) => c.pt.date,
    padLeft,
    width,
    padRight
  );
  const xLabelsSvg = renderXLabelsSvg(xLabels, baselineY);

  const isDense = coords.length > 32;
  const pointsSvg = coords
    .map((c) => {
      const isActive = c.idx === activeIdx;
      const isDown = c.pt.delta < 0;
      const isBase = c.pt.isBaseline;
      const stateClass = isBase ? 'is-base' : isDown ? 'is-down' : 'is-up';
      const showCircle = !isDense || isActive || c.idx === 0 || c.idx === coords.length - 1;
      const radius = isActive ? 4.5 : isBase ? 2.5 : isDense ? 2.2 : 3.2;

      return `
        <g class="chart-point-group" data-chart-idx="${c.idx}" tabindex="0" role="button" aria-label="${escapeHtml(formatDayDateLabel(c.pt.date, false))}: ${escapeHtml(formatRupiah(c.pt.balance))}">
          <circle cx="${c.x.toFixed(1)}" cy="${c.y.toFixed(1)}" r="${isDense ? 8 : 14}" fill="transparent" />
          ${isActive ? `<circle cx="${c.x.toFixed(1)}" cy="${c.y.toFixed(1)}" r="7" class="chart-dot-halo ${stateClass}" />` : ''}
          ${showCircle ? `<circle cx="${c.x.toFixed(1)}" cy="${c.y.toFixed(1)}" r="${radius}" class="chart-dot ${stateClass} ${isActive ? 'is-active' : ''}" />` : ''}
        </g>
      `;
    })
    .join('');

  const activeCoord = coords[activeIdx];
  const deltaClass = activePoint.isBaseline
    ? ''
    : activePoint.delta >= 0
      ? 'text-positive'
      : 'text-negative';
  const deltaLabel = activePoint.isBaseline
    ? activePoint.note || 'Saldo awal'
    : activePoint.delta >= 0
      ? `Nabung +${formatRupiah(activePoint.delta)}`
      : `Ambil ${formatRupiah(activePoint.delta)}`;
  const activeNote = !activePoint.isBaseline && activePoint.note ? activePoint.note : '';

  container.innerHTML = `
    <div class="chart-readout">
      <div class="chart-readout-left">
        <span class="chart-readout-date">${escapeHtml(formatDayDateLabel(activePoint.date, true))}</span>
        <span class="chart-readout-sep" aria-hidden="true">·</span>
        <span class="chart-readout-delta ${deltaClass} tabular-nums">${escapeHtml(deltaLabel)}</span>
      </div>
      <div class="chart-readout-balance tabular-nums">${escapeHtml(formatRupiah(activePoint.balance))}</div>
    </div>
    <p class="chart-note-line ${activeNote ? '' : 'is-placeholder'}">${escapeHtml(activeNote || 'Ketuk titik grafik untuk melihat hari, tanggal & catatan')}</p>
    <svg viewBox="0 0 ${width} ${height}" class="chart-svg" role="img" aria-label="Grafik garis naik turun saldo tabungan">
      <defs>
        <linearGradient id="tsChartGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="var(--positive)" stop-opacity="0.16" />
          <stop offset="100%" stop-color="var(--positive)" stop-opacity="0.0" />
        </linearGradient>
      </defs>
      ${gridSvg}
      ${showZeroLine ? `<line x1="${padLeft}" y1="${zeroY.toFixed(1)}" x2="${width - padRight}" y2="${zeroY.toFixed(1)}" class="chart-zero-line" />` : ''}
      ${areaPath ? `<path d="${areaPath}" fill="url(#tsChartGrad)" />` : ''}
      <line x1="${activeCoord.x.toFixed(1)}" y1="${padTop}" x2="${activeCoord.x.toFixed(1)}" y2="${baselineY}" class="chart-guide-line" />
      ${segmentsSvg}
      ${xLabelsSvg}
      ${pointsSvg}
    </svg>
    <div class="chart-legend">
      <span class="chart-legend-item"><span class="legend-swatch is-up" aria-hidden="true"></span>Naik (Tabung)</span>
      <span class="chart-legend-item"><span class="legend-swatch is-down" aria-hidden="true"></span>Turun (Ambil)</span>
    </div>
  `;
}

function renderFlowBarChart(container, days, selectedIndex) {
  const activeIdx =
    selectedIndex !== null && selectedIndex >= 0 && selectedIndex < days.length
      ? selectedIndex
      : days.length - 1;

  const activeDay = days[activeIdx];
  const rawMaxAbs = Math.max(
    ...days.map((d) => Math.max(d.deposit, d.withdraw)),
    1000
  );
  const maxAbs = niceCeil(rawMaxAbs);

  const width = 340;
  const height = 186;
  const padLeft = 52;
  const padRight = 14;
  const padTop = 14;
  const padBottom = 34;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;
  const baselineY = padTop + plotH;
  const zeroY = padTop + plotH / 2;
  const halfH = plotH / 2 - 4;

  const ticks = [
    { label: `+${formatCompactRupiah(maxAbs)}`, y: padTop + 4 },
    { label: '0', y: zeroY },
    { label: `-${formatCompactRupiah(maxAbs)}`, y: padTop + plotH - 4 },
  ];

  const gridSvg = ticks
    .map(
      (t, idx) =>
        idx === 1
          ? `<text x="${padLeft - 6}" y="${(t.y + 3.5).toFixed(1)}" text-anchor="end" class="chart-axis-text">${escapeHtml(t.label)}</text>`
          : `
      <line x1="${padLeft}" y1="${t.y.toFixed(1)}" x2="${width - padRight}" y2="${t.y.toFixed(1)}" class="chart-grid-line" />
      <text x="${padLeft - 6}" y="${(t.y + 3.5).toFixed(1)}" text-anchor="end" class="chart-axis-text">${escapeHtml(t.label)}</text>
    `
    )
    .join('');

  const slotW = plotW / days.length;
  const barW = Math.max(3, Math.min(24, slotW * 0.62));

  const dayCoords = days.map((d, idx) => ({
    d,
    idx,
    cx: padLeft + idx * slotW + slotW / 2,
  }));

  const barsSvg = dayCoords
    .map(({ d, idx, cx }) => {
      const x = cx - barW / 2;
      const upH = d.deposit > 0 ? Math.max(3, (d.deposit / maxAbs) * halfH) : 0;
      const downH = d.withdraw > 0 ? Math.max(3, (d.withdraw / maxAbs) * halfH) : 0;
      const isActive = idx === activeIdx;
      const hlX = Math.max(padLeft, cx - Math.min(slotW / 2, barW / 2 + 4));
      const hlW = Math.min(width - padRight - hlX, Math.min(slotW, barW + 8));

      return `
        <g class="chart-point-group" data-chart-idx="${idx}" tabindex="0" role="button" aria-label="${escapeHtml(formatDayDateLabel(d.date, false))}: Masuk ${escapeHtml(formatRupiah(d.deposit))}, Ambil ${escapeHtml(formatRupiah(d.withdraw))}">
          <rect x="${(cx - slotW / 2).toFixed(1)}" y="${padTop}" width="${slotW.toFixed(1)}" height="${plotH}" fill="transparent" />
          ${isActive ? `<rect x="${hlX.toFixed(1)}" y="${padTop}" width="${hlW.toFixed(1)}" height="${plotH}" rx="4" class="chart-bar-highlight" />` : ''}
          ${upH > 0 ? `<rect x="${x.toFixed(1)}" y="${(zeroY - upH).toFixed(1)}" width="${barW.toFixed(1)}" height="${upH.toFixed(1)}" rx="2" class="chart-bar-pos ${isActive ? 'is-active' : ''}" />` : ''}
          ${downH > 0 ? `<rect x="${x.toFixed(1)}" y="${zeroY.toFixed(1)}" width="${barW.toFixed(1)}" height="${downH.toFixed(1)}" rx="2" class="chart-bar-neg ${isActive ? 'is-active' : ''}" />` : ''}
        </g>
      `;
    })
    .join('');

  const xLabels = buildDayDateXLabels(
    dayCoords,
    (item) => item.cx,
    (item) => item.d.date,
    padLeft,
    width,
    padRight
  );
  const xLabelsSvg = renderXLabelsSvg(xLabels, baselineY);

  const netPrefix = activeDay.net > 0 ? '+' : '';
  const netClass = activeDay.net >= 0 ? 'text-positive' : 'text-negative';

  container.innerHTML = `
    <div class="chart-readout">
      <div class="chart-readout-left">
        <span class="chart-readout-date">${escapeHtml(formatDayDateLabel(activeDay.date, true))}</span>
        <span class="chart-readout-sep" aria-hidden="true">·</span>
        <span class="text-positive tabular-nums">+${escapeHtml(formatRupiah(activeDay.deposit))}</span>
        <span class="chart-readout-sep" aria-hidden="true">/</span>
        <span class="text-negative tabular-nums">-${escapeHtml(formatRupiah(activeDay.withdraw))}</span>
      </div>
      <div class="chart-readout-balance ${netClass} tabular-nums">${escapeHtml(netPrefix + formatRupiah(activeDay.net))}</div>
    </div>
    <p class="chart-note-line is-placeholder">Ketuk batang grafik untuk melihat hari, tanggal & aliran harian</p>
    <svg viewBox="0 0 ${width} ${height}" class="chart-svg" role="img" aria-label="Grafik batang naik turun tabungan harian">
      ${gridSvg}
      ${barsSvg}
      <line x1="${padLeft}" y1="${zeroY.toFixed(1)}" x2="${width - padRight}" y2="${zeroY.toFixed(1)}" class="chart-zero-line" />
      ${xLabelsSvg}
    </svg>
    <div class="chart-legend">
      <span class="chart-legend-item"><span class="legend-swatch is-up" aria-hidden="true"></span>Naik (Masuk)</span>
      <span class="chart-legend-item"><span class="legend-swatch is-down" aria-hidden="true"></span>Turun (Ambil)</span>
    </div>
  `;
}
