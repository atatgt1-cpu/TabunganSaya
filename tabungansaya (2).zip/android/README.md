# TabunganSaya Android WebView Wrapper

Proyek Android ringan ini membungkus aplikasi web **TabunganSaya** (`app/src/main/assets/index.html`) menggunakan **Android WebView** bawaan tanpa library berat, sehingga ukuran APK sangat kecil, hemat RAM, dan tidak ngeleg.

## File Penting yang Tersedia
- `app/src/main/AndroidManifest.xml` — Konfigurasi aplikasi, akselerasi hardware, dan tanpa izin internet (100% lokal/offline).
- `app/src/main/java/id/tabungansaya/app/MainActivity.java` — WebView ringan dengan `domStorageEnabled` (`localStorage` tersimpan permanen) serta dukungan Backup & Restore `.json`.
- `app/build.gradle` — Konfigurasi `minifyEnabled true`, `shrinkResources true`, dan `signingConfigs` untuk tanda tangan digital APK.
- `gradle/wrapper/gradle-wrapper.properties` — Versi Gradle `8.7` yang kompatibel dengan Android Gradle Plugin `8.5.2`.
- `../.github/workflows/build-apk.yml` — Workflow otomatis untuk menghasilkan file `.apk` bertanda tangan digital lewat GitHub Actions tanpa perlu Android Studio.

## Opsi 1 — Build `.apk` Otomatis Tanpa PC (GitHub Actions)
1. Upload/push folder proyek ini ke repository GitHub Anda.
2. Buka tab **Actions** di repository GitHub Anda -> pilih **Build Android APK** -> klik **Run workflow** (atau otomatis berjalan saat push ke `main`).
3. Setelah selesai (~1-2 menit), unduh artefak **`TabunganSaya-APK`** berisi file `.apk` siap pasang di HP Android.

## Opsi 2 — Build `.apk` di Komputer (Android Studio / Gradle)
1. **Buat keystore tanda tangan digital (.jks):**
   ```bash
   keytool -genkey -v -keystore app/tabungansaya-release.jks \
     -alias tabungansaya -keyalg RSA -keysize 2048 -validity 10000
   ```
   *(Gunakan password `tabungansaya123` atau sesuaikan lewat environment variable `KEYSTORE_PASSWORD` & `KEY_PASSWORD`).*

2. **Build APK Release bertanda tangan digital:**
   - Buka folder `android/` di **Android Studio** -> menu **Build → Generate Signed Bundle / APK**, **atau** jalankan lewat terminal (jika Gradle 8.7 & Android SDK 34 sudah terpasang):
   ```bash
   gradle assembleRelease
   ```
   Hasil APK siap install berada di `app/build/outputs/apk/release/app-release.apk`.
