-keepattributes JavascriptInterface
-keep class id.tabungansaya.app.MainActivity$AndroidBridge {
    *;
}
-keepclassmembers class id.tabungansaya.app.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
